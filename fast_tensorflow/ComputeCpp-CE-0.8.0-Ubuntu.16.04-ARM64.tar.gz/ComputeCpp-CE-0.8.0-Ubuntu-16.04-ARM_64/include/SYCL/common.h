/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp
*******************************************************************************/

/*!
  @file common.h

  @brief File containing internal declarations relating to the implementation
*/

#ifndef RUNTIME_INCLUDE_SYCL_COMMON_H_
#define RUNTIME_INCLUDE_SYCL_COMMON_H_

// The predefines header needs to be the very first header included
#include "SYCL/predefines.h"

#include "SYCL/include_opencl.h"

#define _SCL_SECURE_NO_WARNINGS 1
#include <bitset>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace cl {
namespace sycl {
/** @cond COMPUTECPP_DEV */

/*
 * @brief typedef of unsigned short for use as number of dimensions.
 */
using dim_t = unsigned short;

/*!
  @brief Enum class for specifying the type of a sycl_log object
*/
enum class log_type {
  none,            ///< default
  error,           ///< synchronous runtime error - results in an exception
  callback_error,  ///< asynchronous runtime error - results in an exception
                   ///  thrown to the async_handler
  warning,         ///< runtime warning - results in a warning written to
                   ///  standard output
  info,            ///< runtime information - results in a log being written to
                   ///  standard output
  assert,          ///< runtime assertion based on condition - results in an
                   ///  error being written to standard output
  unreachable,     ///< runtime unreachable for a code path that should not be
                   ///  reached - results in an error being written to standard
                   ///  output
  not_implemented  ///< not implemented feature - results in a not implemented
                   ///  feature specific error being written to standard output
};
/** COMPUTECPP_DEV @endcond */

namespace access {

/*!
  @brief Enum class for specifying the access mode for the accessor.
*/
enum class mode : unsigned int {
  read = 0,                ///< read-only access
  write = 1,               ///< write-only access, previous contents not
                           ///  discarded
  read_write = 2,          ///< read and write access
  discard_write = 3,       ///< write-only access, previous contents discarded
  discard_read_write = 4,  ///< read and write access, previous contents
                           ///  discarded
  atomic = 5               ///< atomic access
};

/*!
  @brief Enum class for specifying the access target for the accessor.
*/
enum class target : unsigned int {
  host_buffer = 0,      ///< Access a buffer immediately in host code
  global_buffer = 1,    ///< Access buffer via global memory
  constant_buffer = 2,  ///< Access buffer via constant memory
  local = 3,            ///< Access work-group-local memory
  host_image = 4,       ///< Access an image immediately in host code
  image = 5,            ///< Access an image
  image_array = 6       ///< Access an image array
};

}  // namespace access

namespace access {
/*!
  @brief Enum class for specifying whether the accessor is a placeholder
*/
enum class placeholder {
  false_t,  ///< Normal accessor
  true_t    ///< Placeholder accessor
};
}  // namespace access

namespace detail {

enum enum_access_mode {
  ACCESS_MODE_NONE,
  ACCESS_MODE_READ,
  ACCESS_MODE_WRITE,
  ACCESS_MODE_READ_WRITE,
  ACCESS_MODE_DISCARD_WRITE,
  ACCESS_MODE_DISCARD_READ_WRITE
};

enum enum_access_location {
  ACCESS_LOCATION_NONE,
  ACCESS_LOCATION_HOST,
  ACCESS_LOCATION_DEVICE
};

enum enum_access_type {
  ACCESS_TYPE_NONE,
  ACCESS_TYPE_BUFFER,
  ACCESS_TYPE_IMAGE,
  ACCESS_TYPE_LOCAL,
  ACCESS_TYPE_CLBUFFER,
  ACCESS_TYPE_CLIMAGE
};

enum enum_access_address_space {
  ACCESS_ADDRESS_SPACE_NONE,
  ACCESS_ADDRESS_SPACE_NA,
  ACCESS_ADDRESS_SPACE_GLOBAL,
  ACCESS_ADDRESS_SPACE_CONSTANT,
  ACCESS_ADDRESS_SPACE_LOCAL
};

/** enum_data_source
 * The source of the initial data for buffers or images, if any.
 */
enum enum_data_source {
  NO_DATA_SOURCE,
  DATA_SOURCE_HOST,
  DATA_SOURCE_MEM_OBJECT,
  DATA_SOURCE_GL_OBJECT,
  DATA_SOURCE_DEVICE,
  DATA_SOURCE_BUFFER  // Specific case for sub-buffers
};

struct NullDeleter {
  void operator()(void *){};
};
/**
The enum_accessor_type enumeration is used to specify the type of an accessor
object; this type is stored
within the shared base type of both accessor and host_accessor; accessor_impl.
ACCESSOR_TYPE_HOST refers
to a host_accessor. ACCESSOR_TYPE_DEVICE refers to an accessor.
*/
enum enum_accessor_type { ACCESSOR_TYPE_HOST, ACCESSOR_TYPE_DEVICE };

}  // namespace detail

/*******************************************************************************
    STL definitions
*******************************************************************************/

template <typename T, typename Alloc = std::allocator<T>>
using vector_class = std::vector<T, Alloc>;

using string_class = std::string;

template <typename T>
using function_class = std::function<T>;

using mutex_class = std::mutex;

template <typename T, class D = std::default_delete<T>>
using unique_ptr_class = std::unique_ptr<T, D>;

template <typename T>
using shared_ptr_class = std::shared_ptr<T>;

template <typename T>
using weak_ptr_class = std::weak_ptr<T>;

template <typename T>
using hash_class = std::hash<T>;

template <size_t Size>
using bitset_class = std::bitset<Size>;

/*******************************************************************************
    Byte type alias
*******************************************************************************/

using byte = unsigned char;

/*******************************************************************************
    accessor forward declaration
*******************************************************************************/

/**
  @brief Forward declaration of accessor.
*/
template <typename elemT, int kDims, access::mode kMode, access::target kTarget,
          access::placeholder isPlaceholder = access::placeholder::false_t>
class accessor;
namespace detail {
/**
  @brief Forward declaration of accessor_common.
*/
template <typename elemT, int kDims, access::mode kMode, access::target kTarget,
          access::placeholder isPlaceholder>
class accessor_common;
}

/*******************************************************************************
    device_arg_info
*******************************************************************************/

namespace detail {

/*!
@brief Specialized template struct that contains a typedef for the element of
device_index_array based on the address bits of the compiler. This struct is
specialized for different values for kPtrSize.
@tparam kPtrSize Specifies the pointer size in bytes.
*/
template <size_t kPtrSize>
struct device_arg_info {
  // This struct contains a work around for an ARM(32bit) - KAI(64bit)
  // host/device combination which requires the host side to be treated as 64bit
  // in order to match the device side.
  static_assert(kPtrSize, "Arch size not supported.");
};

template <>
struct device_arg_info<4> {
#ifdef COMPUTECPP_KAI
  using elem_type = int32_t;
#else
  using elem_type = int32_t;
#endif  // COMPUTECPP_KAI
};

template <>
struct device_arg_info<8> {
#ifdef COMPUTECPP_KAI
  using elem_type = int16_t;
#else
  using elem_type = int32_t;
#endif  // COMPUTECPP_KAI
};

/*******************************************************************************
    binary_info
*******************************************************************************/

/*!
 * @brief Alias for the address of a binary data.
 */
using binary_address = const unsigned char *;

/**
* @brief The binary_info struct is used to contain all of the meta data
* associated with a particular ComputeCpp module.
*/
struct kernel_binary_info {
  /// Target for which the module blob was compiled for
  const char *const target;
  /// Architecture size for which the module blob was compiled for
  const size_t device_address_bits;
  /// Module blob data
  binary_address const data;
  /// Module blob size
  const size_t data_size;
  // Extensions used by the module
  const char *const *const used_extensions;
};

/*******************************************************************************
    global index linearization function
*******************************************************************************/

/*!
@brief Global function for calculating a row major linearized index from an id
and range.
@param index0 Element 0 of the index.
@param index1 Element 1 of the index.
@param index2 Element 2 of the index.
@param range0 Element 0 of the range.
@param range1 Element 1 of the range.
@param range2 Element 2 of the range.
@return The linearized index.
*/
inline size_t construct_linear_row_major_index(size_t index0, size_t index1,
                                               size_t index2, size_t /*range0*/,
                                               size_t range1, size_t range2) {
  return index2 + (index1 * range2) + (index0 * range1 * range2);
}

/*******************************************************************************
    Helper functions for the copy API methods
*******************************************************************************/

/**
  @brief Helper struct that checks whether an access mode includes read access
  @tparam accessMode Access mode to check
*/
template <cl::sycl::access::mode accessMode>
struct is_read_mode {
  /**
    @brief True if access mode includes read access
  */
  static constexpr bool value =
      ((accessMode == cl::sycl::access::mode::read) ||
       (accessMode == cl::sycl::access::mode::read_write) ||
       (accessMode == cl::sycl::access::mode::discard_read_write));
};

/**
  @brief Helper struct that checks whether an access mode includes write access
  @tparam accessMode Access mode to check
*/
template <cl::sycl::access::mode accessMode>
struct is_write_mode {
  /**
    @brief True if access mode includes write access
  */
  static constexpr bool value =
      ((accessMode == cl::sycl::access::mode::write) ||
       (accessMode == cl::sycl::access::mode::read_write) ||
       (accessMode == cl::sycl::access::mode::discard_write) ||
       (accessMode == cl::sycl::access::mode::discard_read_write));
};

/**
  @brief Helper struct that checks whether data of two different underlying
         types can be copied from origin to destination
  @tparam TOrig Underlying type of the origin data
  @tparam TDest Underlying type of the destination data
*/
template <typename TOrig, typename TDest>
struct can_copy_types {
  /**
    @brief True if types are the same,
           or if origin type is a const version of destination type,
           or if one type is void,
           or if origin is const void
  */
  static constexpr bool value = ((std::is_same<TOrig, TDest>::value) ||
                                 (std::is_same<TOrig, const TDest>::value) ||
                                 (std::is_same<TOrig, void>::value) ||
                                 (std::is_same<TDest, void>::value) ||
                                 (std::is_same<TOrig, const void>::value));
};

}  // namespace detail
}  // namespace sycl
}  // namespace cl

////////////////////////////////////////////////////////////////////////////////

#ifndef COMPUTECPP_HARNESS_DEVICE
// This header has to be included before all the other headers
#include "SYCL/base.h"
#endif  // COMPUTECPP_HARNESS_DEVICE

#endif  // RUNTIME_INCLUDE_SYCL_COMMON_H_

////////////////////////////////////////////////////////////////////////////////
