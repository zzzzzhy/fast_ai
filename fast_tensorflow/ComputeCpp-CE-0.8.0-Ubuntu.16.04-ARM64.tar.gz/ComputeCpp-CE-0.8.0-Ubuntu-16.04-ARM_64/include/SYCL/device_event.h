/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
 * @file device_event.h
 *
 * @brief Declaration of the device event
 */

#ifndef RUNTIME_INCLUDE_SYCL_DEVICE_EVENT_H_
#define RUNTIME_INCLUDE_SYCL_DEVICE_EVENT_H_
namespace cl {
namespace sycl {
namespace detail {
class nd_item_base;
}

/**
 * @brief Event for asynchronous operations on the device side.
 * Currently implemented as a no-op.
 */
class device_event {
  friend class nd_item<1>;
  friend class nd_item<2>;
  friend class nd_item<3>;
  friend class group<1>;
  friend class group<2>;
  friend class group<3>;

  device_event() = default;

 public:
  /**
   * @brief Wait for the event to finalize
   */
  void wait() const {
#ifdef __SYCL_DEVICE_ONLY__
    ::cl::sycl::detail::barrier(
        static_cast<cl_uint>(access::fence_space::global_and_local));
#else
// Barrier is not needed on the host because the operation is
// synchronous
#endif
  }

  /**
   * @brief Destroys the device event. Performs a wait.
   */
  ~device_event() { wait(); }
};

}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_DEVICE_EVENT_H_
