/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

    * atomic_device.h *

*******************************************************************************/

/*!
 * @file atomic_device.h
 * @brief This file contains an implementation of the member functions of the
 *        atomic class for the device.
 */

#ifndef RUNTIME_INCLUDE_SYCL_ATOMIC_DEVICE_H_
#define RUNTIME_INCLUDE_SYCL_ATOMIC_DEVICE_H_

#include "SYCL/atomic.h"
#include "SYCL/common.h"
#include "SYCL/sycl_device_builtins.h"
#include "SYCL/type_traits.h"

namespace cl {
namespace sycl {

#ifdef __SYCL_DEVICE_ONLY__

/** @cond COMPUTECPP_DEV */

namespace detail {
/*!
 * @brief helper function for atomic_compare_exchange on device
 * @param old the old value of *m_data
 * @param expected the expected value of *m_data
 * @return old == expected
 */
template <typename T>
cl_bool cmpxchg_helper(T old, T &expected) {
  if (old == expected) {
    return true;
  } else {
    expected = old;
    return false;
  }
}
}  // namespace detail

/* General implementation
 * --------------------------------------------------------------------------*/

// OpenCL 1.2 has no store operation, so swap with the desired value, then
// discard the old value (i.e. *m_data).
template <typename T, access::address_space AddressSpace>
inline void atomic<T, AddressSpace>::store(T operand,
                                           memory_order mem_order) volatile {
  ::cl::sycl::detail::atomic_xchg(m_data, operand);
}

// OpenCL 1.2 has no load operation, so add zero to obtain the "old" value.
template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::load(memory_order mem_order) const volatile {
  return ::cl::sycl::detail::atomic_add(m_data, 0);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::exchange(T operand,
                                           memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_xchg(m_data, operand);
}

// OpenCL 1.2 does not implement compare_and_exchange in the same way as C++11,
// so this function emulates the behavior on the device. It attempts to figure
// out if the call to cmpxchg actually altered the atomic value by capturing the
// old value then comparing it to expected. If they are the same, then the
// comparison will have succeeded, so we can return true. If they aren't, then
// comparison failed, so we need to update expected manually then return false.
// The helper function performs this part of the logic, since it is shared by
// all compare_exchange device implementations.
template <typename T, access::address_space AddressSpace>
inline cl_bool atomic<T, AddressSpace>::compare_exchange_strong(
    T &expected, T desired, memory_order success, memory_order fail) volatile {
  auto old = ::cl::sycl::detail::atomic_cmpxchg(m_data, expected, desired);
  return ::cl::sycl::detail::cmpxchg_helper(old, expected);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::fetch_add(T operand,
                                            memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_add(m_data, operand);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::fetch_sub(T operand,
                                            memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_sub(m_data, operand);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::fetch_and(T operand,
                                            memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_and(m_data, operand);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::fetch_or(T operand,
                                           memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_or(m_data, operand);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::fetch_xor(T operand,
                                            memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_xor(m_data, operand);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::fetch_min(T operand,
                                            memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_min(m_data, operand);
}

template <typename T, access::address_space AddressSpace>
inline T atomic<T, AddressSpace>::fetch_max(T operand,
                                            memory_order mem_order) volatile {
  return ::cl::sycl::detail::atomic_max(m_data, operand);
}

/* <cl_long, global> specialization
 * --------------------------------------------------------------------------*/

template <>
inline void atomic<cl_long, access::address_space::global_space>::store(
    cl_long operand, memory_order mem_order) volatile {
  ::cl::sycl::detail::atom_xchg(m_data, operand);
  return;
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::load(
    memory_order mem_order) const volatile {
  return ::cl::sycl::detail::atom_add(m_data, 0);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::exchange(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xchg(m_data, operand);
}

template <>
inline cl_bool
atomic<cl_long, access::address_space::global_space>::compare_exchange_strong(
    cl_long &expected, cl_long desired, memory_order success,
    memory_order fail) volatile {
  cl_long old = ::cl::sycl::detail::atom_cmpxchg(m_data, expected, desired);
  return ::cl::sycl::detail::cmpxchg_helper(old, expected);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::fetch_add(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_add(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::fetch_sub(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_sub(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::fetch_and(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_and(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::fetch_or(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_or(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::fetch_xor(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xor(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::fetch_min(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_min(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::global_space>::fetch_max(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_max(m_data, operand);
}

/* <cl_ulong, global> specialization
 *
 --------------------------------------------------------------------------*/

template <>
inline void atomic<cl_ulong, access::address_space::global_space>::store(
    cl_ulong operand, memory_order mem_order) volatile {
  ::cl::sycl::detail::atom_xchg(m_data, operand);
  return;
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::global_space>::load(
    memory_order mem_order) const volatile {
  return ::cl::sycl::detail::atom_add(m_data, 0);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::global_space>::exchange(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xchg(m_data, operand);
}

template <>
inline cl_bool
atomic<cl_ulong, access::address_space::global_space>::compare_exchange_strong(
    cl_ulong &expected, cl_ulong desired, memory_order success,
    memory_order fail) volatile {
  cl_ulong old = ::cl::sycl::detail::atom_cmpxchg(m_data, expected, desired);
  return ::cl::sycl::detail::cmpxchg_helper(old, expected);
}

template <>
inline cl_ulong
atomic<cl_ulong, access::address_space::global_space>::fetch_add(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_add(m_data, operand);
}

template <>
inline cl_ulong
atomic<cl_ulong, access::address_space::global_space>::fetch_sub(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_sub(m_data, operand);
}

template <>
inline cl_ulong
atomic<cl_ulong, access::address_space::global_space>::fetch_and(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_and(m_data, operand);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::global_space>::fetch_or(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_or(m_data, operand);
}

template <>
inline cl_ulong
atomic<cl_ulong, access::address_space::global_space>::fetch_xor(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xor(m_data, operand);
}

template <>
inline cl_ulong
atomic<cl_ulong, access::address_space::global_space>::fetch_min(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_min(m_data, operand);
}

template <>
inline cl_ulong
atomic<cl_ulong, access::address_space::global_space>::fetch_max(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_max(m_data, operand);
}

/* <cl_float, global> specialization
 *
 --------------------------------------------------------------------------*/

// Unlike store, there is no way to non-destructively update m_data and return
// the old value, so a simple load is issued. This should be atomic regardless.
template <>
inline cl_float atomic<cl_float, access::address_space::global_space>::load(
    memory_order mem_order) const volatile {
  return *m_data;
}

/* <cl_long, local> specialization
 *
 --------------------------------------------------------------------------*/

template <>
inline void atomic<cl_long, access::address_space::local_space>::store(
    cl_long operand, memory_order mem_order) volatile {
  ::cl::sycl::detail::atom_xchg(m_data, operand);
  return;
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::load(
    memory_order mem_order) const volatile {
  return ::cl::sycl::detail::atom_add(m_data, 0);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::exchange(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xchg(m_data, operand);
}

template <>
inline cl_bool
atomic<cl_long, access::address_space::local_space>::compare_exchange_strong(
    cl_long &expected, cl_long desired, memory_order success,
    memory_order fail) volatile {
  cl_long old = ::cl::sycl::detail::atom_cmpxchg(m_data, expected, desired);
  return ::cl::sycl::detail::cmpxchg_helper(old, expected);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::fetch_add(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_add(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::fetch_sub(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_sub(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::fetch_and(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_and(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::fetch_or(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_or(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::fetch_xor(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xor(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::fetch_min(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_min(m_data, operand);
}

template <>
inline cl_long atomic<cl_long, access::address_space::local_space>::fetch_max(
    cl_long operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_max(m_data, operand);
}

/* <cl_ulong, local> specialization
 *
 --------------------------------------------------------------------------*/

template <>
inline void atomic<cl_ulong, access::address_space::local_space>::store(
    cl_ulong operand, memory_order mem_order) volatile {
  ::cl::sycl::detail::atom_xchg(m_data, operand);
  return;
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::load(
    memory_order mem_order) const volatile {
  return ::cl::sycl::detail::atom_add(m_data, 0);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::exchange(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xchg(m_data, operand);
}

template <>
inline cl_bool
atomic<cl_ulong, access::address_space::local_space>::compare_exchange_strong(
    cl_ulong &expected, cl_ulong desired, memory_order success,
    memory_order fail) volatile {
  cl_ulong old = ::cl::sycl::detail::atom_cmpxchg(m_data, expected, desired);
  return ::cl::sycl::detail::cmpxchg_helper(old, expected);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::fetch_add(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_add(m_data, operand);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::fetch_sub(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_sub(m_data, operand);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::fetch_and(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_and(m_data, operand);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::fetch_or(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_or(m_data, operand);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::fetch_xor(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_xor(m_data, operand);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::fetch_min(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_min(m_data, operand);
}

template <>
inline cl_ulong atomic<cl_ulong, access::address_space::local_space>::fetch_max(
    cl_ulong operand, memory_order mem_order) volatile {
  return ::cl::sycl::detail::atom_max(m_data, operand);
}

/* <cl_float, local> specialization
 *
 --------------------------------------------------------------------------*/

template <>
inline cl_float atomic<cl_float, access::address_space::local_space>::load(
    memory_order mem_order) const volatile {
  return *m_data;
}

/** COMPUTECPP_DEV @endcond  */

#endif  // __SYCL_DEVICE_ONLY__

}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_ATOMIC_DEVICE_H_
