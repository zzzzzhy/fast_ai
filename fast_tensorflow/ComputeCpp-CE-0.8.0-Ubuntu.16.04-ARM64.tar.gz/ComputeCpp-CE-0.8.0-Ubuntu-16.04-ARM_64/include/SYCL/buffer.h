/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file buffer.h

  @brief This file contains the @ref cl::sycl::buffer class API
*/

#ifndef RUNTIME_INCLUDE_SYCL_BUFFER_H_
#define RUNTIME_INCLUDE_SYCL_BUFFER_H_

#include "SYCL/common.h"
#include "SYCL/context.h"
#include "SYCL/event.h"
#include "SYCL/info.h"
#include "SYCL/property.h"
#include "SYCL/storage_mem.h"

namespace cl {
namespace sycl {
namespace detail {
class buffer;
class buffer_mem;
class data_block;
class storage_mem;
}  // namespace detail

template <typename dataT, int dimensions, access::mode accessMode,
          access::target accessTarget, access::placeholder isPlaceholder>
class accessor;

class handler;

namespace property {
namespace buffer {

/**
 * @brief The use_host_ptr property adds the requirement that the SYCL runtime
 *        must not allocate any memory for the SYCL buffer and instead uses the
 *        provided host pointer directly.
 **/
class COMPUTECPP_EXPORT use_host_ptr : public detail::property_base {
 public:
  use_host_ptr() : detail::property_base(detail::property_enum::use_host_ptr) {}
};

/**
 * @brief The use_mutex property adds the requirement that the memory which is
 *        owned by the SYCL buffer can be shared with the application via a
 *        mutex_class provided to the property. The mutex is locked by the
 *        runtime whenever the data is in use and unlocked otherwise. Data is
 *        synchronized with host data when the mutex is unlocked by the runtime.
 **/
class COMPUTECPP_EXPORT use_mutex : public detail::property_base {
 public:
  /**
   * @brief Constructs a SYCL use_mutex property instance with a reference to
   *        mutexRef parameter provided.
   * @param mutexRef Mutex to be associated with the property and the buffer.
   */
  use_mutex(mutex_class &mutexRef)
      : detail::property_base(detail::property_enum::use_mutex),
        m_mutexRef(&mutexRef) {}

  /**
   * @brief Retrieve the mutex provided on construction
   * @return Mutex associated with this property
   */
  inline mutex_class *get_mutex_ptr() const { return m_mutexRef; }

 private:
  /**
   * @brief Store a pointer to the mutex provided by the user
   */
  mutex_class *m_mutexRef;
};

/**
 * @brief The context_bound property adds the requirement that the SYCL buffer
 *        can only be associated with a single SYCL context that is provided to
 *        the property.
 */
class COMPUTECPP_EXPORT context_bound : public detail::property_base {
 public:
  /**
   * @brief Constructs a SYCL context_bound property instance with a copy of a
   *        SYCL context.
   * @param boundContext Context to be bound to the buffer.
   */
  context_bound(const context &boundContext)
      : detail::property_base(detail::property_enum::context_bound),
        m_boundContext(boundContext.get_impl()) {}

  /**
   * @brief Retrieves the context provided on construction
   * @return The context bound to the buffer
   */
  inline context get_context() const { return context(m_boundContext); }

 private:
  /**
   * @brief Store the context provided by the user
   */
  dcontext_shptr m_boundContext;
};

}  // namespace buffer
}  // namespace property

/*! @cond COMPUTECPP_DEV */

/** Class.
 *  buffer_mem hides the implementation details using a PIMPL pattern,
 *  Redirects all methods to the implementation, and only requires the
 *  declaration of detail::buffer to exist, but not the full definition.
 *  Methods defined here will be available and visible to the user.
 *  The pointer_origin enum class is used to differentiate the different
 *  possible origins from the user-pointer, and facilitate the calls to the
 *  appropriate internal constructor afterwards.
 */
class COMPUTECPP_EXPORT buffer_mem : public storage_mem {
 public:
  enum class pointer_origin { IS_RAW, IS_SHARED, IS_RAW_CONST, IS_EMPTY };

 protected:
  explicit buffer_mem(std::string error_message) : storage_mem() {
    COMPUTECPP_CL_ERROR_CODE_MSG(CL_SUCCESS,
                                 detail::cpp_error_code::NOT_SUPPORTED_ERROR,
                                 nullptr, error_message.c_str());
  }

 public:
  /**
   * @brief Constructs an storage mem object for a buffer from the
   * given host pointer, passed as a shared_pointer Rvalue.
   *
   * @param shared_ptr_class<void> Shared pointer containing the host pointer
   * @param short  Number of dimensions (1..3)
   * @param index_array Range/shape of the buffer
   * @param size_t Size of each element of the buffer in bytes
   * @param unique_ptr<detail::base_allocator> Allocator provided by the user
   * @param propList List of buffer properties
   */
  buffer_mem(shared_ptr_class<void> &&hostPointer, dim_t numDims,
             const detail::index_array &rI, size_t elementSize,
             pointer_origin pOrigin,
             unique_ptr_class<detail::base_allocator> &&bA,
             const property_list &propList);

  /**
   * @brief Constructs a sub-buffer from the given buffer.
   *
   * @param buffer_mem The parent buffer of this sub-buffer
   * @param index_array The base offset to start the sub-buffer
   * @param subRange  The range/shape of the sub-buffer
   */
  buffer_mem(buffer_mem &parentBuf, const detail::index_array &baseIndex,
             const detail::index_array &subRange);

  /**
   * @brief Constructs an interop buffer from an existing OpenCL event.
   *
   * @param cl_mem OpenCL memory object
   * @param queue Queue where the cl_mem object is used
   * @param event Event that, if available, the runtime has to wait before
   *        using the cl_mem object
   * @param short Number of dimensions
   * @param size_t Size of each element
   * @param unique_ptr<detail::base_allocator>  Allocator provided by the user
   */
  COMPUTECPP_DEPRECATED_API(
      "This constructor is deprecated in SYCL 1.2.1, please use the one "
      "accepting a SYCL Context instead.")
  buffer_mem(cl_mem memObject, queue &fromQueue, event syclEvent, dim_t numDims,
             size_t elementSize, unique_ptr_class<detail::base_allocator> &&bA);

  /**
  * @brief Constructs an interop buffer from an existing OpenCL event.
  *
  * @param cl_mem OpenCL memory object
  * @param syclContext context where the cl_mem object is used
  * @param event Event that, if available, the runtime has to wait before
  *        using the cl_mem object
  * @param short Number of dimensions
  * @param size_t Size of each element
  * @param unique_ptr<detail::base_allocator>  Allocator provided by the user
  */
  buffer_mem(cl_mem memObject, const context &syclContext, event syclEvent,
             dim_t numDims, size_t elementSize,
             unique_ptr_class<detail::base_allocator> &&bA);

#if COMPUTECPP_OPENGL_INTEROP_AVAILABLE
  /**
   * @brief Creates an OpenGL interop buffer
   *
   * @param cl::sycl::context A SYCL context with GL interoperability
   * @param GLuint The OpenGL buffer to interop with
   * @param short Number of dimensions
   * @param std::unique_ptr<detail::base_allocator> Allocator to use
   */
  buffer_mem(cl::sycl::context &glEnabledContext, GLuint glInteropBuffer,
             dim_t numDims, size_t elementSize,
             std::unique_ptr<detail::base_allocator> &&bA);
#endif  // COMPUTECPP_OPENGL_INTEROP_AVAILABLE

  /**
   * @brief Default destructor
   */
  ~buffer_mem() = default;

  /**
   * @brief Internal constructor used for testing
   */
  explicit buffer_mem(dmem_shptr impl);

  /**
   * @brief Default copy constructor.
   */
  buffer_mem(const buffer_mem &rhs) : storage_mem(rhs.get_impl()) {}

  /**
   * @brief Default move constructor.
   * @param rhs will be destroyed after the operation.
   */
  buffer_mem(buffer_mem &&rhs) : storage_mem(rhs.get_impl()) {}

  /**
   * @brief Copy assignment.
   * @param rhs the buffer_mem to be copied.
   */
  buffer_mem &operator=(const buffer_mem &rhs) {
    this->set_impl(rhs.get_impl());
    return *this;
  }
  /*!
  @brief Checks whether a reinterpreted SYCL buffer with new element size
  denoted by reinterpretElementSize and new range denoted by reinterpretRange
  will be valid if using ptr as the implementation. The size of the
  implementation and the calculated size of the reinterpreted buffer should
  match. Otherwise an exception is thrown.
  @param ReinterpretElementSize the size of an individual element in bytes
  @param reinterpretDims the dimensions count of the reinterpreted buffer.
  @param reinterpretRange the range that the new buffer will use.
  @param impl the intented buffer implementation
  @return the implementation of the reinterpreted buffer with the requested
  parameters
  @throw detail::cpp_error_code::INVALID_OBJECT_ERROR (509) if the size of the
  reinterpreted buffer and the size of the original buffer do not match
  */
  dmem_shptr reinterpret_buffer(size_t reinterpretElementSize,
                                size_t reinterpretDims,
                                const detail::index_array &reinterpretRange,
                                const dmem_shptr &impl) const;

  /**
   * @brief Move assignment operator.
   * @param rhs the buffer_mem to have its contents moved. The object will be
   * destroyed after the operation.
   */
  buffer_mem &operator=(buffer_mem &&rhs) {
    this->set_impl(rhs.get_impl());
    return *this;
  }

  /**
   * @brief Determines if lhs and rhs are equal
   * @param lhs Left-hand-side object in comparison
   * @param rhs Right-hand-side object in comparison
   * @return True if same underlying object
   */
  friend inline bool operator==(const buffer_mem &lhs, const buffer_mem &rhs) {
    return (lhs.get_impl() == rhs.get_impl());
  }

  /**
   * @brief Determines if lhs and rhs are not equal
   * @param lhs Left-hand-side object in comparison
   * @param rhs Right-hand-side object in comparison
   * @return True if different underlying objects
   */
  friend inline bool operator!=(const buffer_mem &lhs, const buffer_mem &rhs) {
    return !(lhs == rhs);
  }

  /**
   * @brief True if the buffer is a sub-buffer
   */
  bool is_sub_buffer() const;
};
/*! @endcond */

/*!
@brief buffer is the public interface for the buffer object implementation. The
template allows the creation of specific types and number of dimensions.
 */
template <typename T, int dimensions = 1,
          typename AllocatorT = default_allocator<T>>
class buffer : public buffer_mem {
 public:
  /*! @brief Helper for the user, alias for type T */
  using value_type = T;

  /*! @brief Helper for the user, alias for reference to type T */
  using reference = T &;

  /*! @brief Helper for the user, alias for const reference to type T */
  using const_reference = const T &;

  /*! @brief Helper for the user, alias for the type of the allocator */
  using allocator_type = AllocatorT;

  /*!
  @brief Constructs a buffer without a host pointer.
  The runtime will only use internally allocated memory and
  no copy in or out is defined.
  The given allocator is used to create internal storage in case the
  runtime requires it.
  @param r Range of the buffer
  @param propList List of buffer properties
  */
  buffer(const range<dimensions> &r, const property_list &propList = {})
      : buffer_mem(
            shared_ptr_class<void>(nullptr, detail::NullDeleter()), dimensions,
            r, sizeof(T), buffer_mem::pointer_origin::IS_EMPTY,
            detail::make_base_allocator<T, AllocatorT>::get(), propList) {}

  /*!
  @brief Constructs a buffer without a host pointer.
  The runtime will only use internally allocated memory and
  no copy in or out is defined.
  The given allocator is used to create internal storage in case the
  runtime requires it.
  @param r Range of the buffer
  @param allocator The allocator used to create internal storage in case the
             runtime requires it.
  @param propList List of buffer properties
  */
  buffer(const range<dimensions> &r, AllocatorT allocator,
         const property_list &propList = {})
      : buffer_mem(shared_ptr_class<void>(nullptr, detail::NullDeleter()),
                   dimensions, r, sizeof(T),
                   buffer_mem::pointer_origin::IS_EMPTY,
                   detail::make_base_allocator<T, AllocatorT>::get(allocator),
                   propList) {}

  /*!
  @brief Constructs a buffer with a host pointer.
  In this case there is a host pointer, potentially initialized, but
  the user has not given the runtime any ownership, therefore the
  deleter has to be null.
  A Copy in is performed if the pointer is not null.
  If it is null, the data is initialized (new) inside the runtime.
  A copy out to hostPointer is performed by default.
  @param hostPointer Pointer to host data
  @param r Range of the buffer
  @param propList List of buffer properties
  */
  buffer(T *hostPointer, const range<dimensions> &r,
         const property_list &propList = {})
      : buffer_mem(
            std::move(shared_ptr_class<void>(static_cast<void *>(hostPointer),
                                             detail::NullDeleter())),
            dimensions, r, sizeof(T), pointer_origin::IS_RAW,
            detail::make_base_allocator<T, AllocatorT>::get(), propList) {}

  /*!
  @brief Constructs a buffer with a host pointer.
  In this case there is a host pointer, potentially initialized, but
  the user has not given the runtime any ownership, therefore the
  deleter has to be null.
  A Copy in is performed if the pointer is not null.
  If it is null, the data is initialized (new) inside the runtime.
  A copy out to hostPointer is performed by default.
  @param hostPointer Pointer to host data
  @param r Range of the buffer
  @param allocator The allocator used to create internal storage in case the
             runtime requires it.
  @param propList List of buffer properties
  */
  buffer(T *hostPointer, const range<dimensions> &r, AllocatorT allocator,
         const property_list &propList = {})
      : buffer_mem(
            std::move(shared_ptr_class<void>(static_cast<void *>(hostPointer),
                                             detail::NullDeleter())),
            dimensions, r, sizeof(T), pointer_origin::IS_RAW,
            detail::make_base_allocator<T, AllocatorT>::get(allocator),
            propList) {}

  /*!
  @brief Constructs a buffer with host pointer.
  The user has given a const pointer, but the buffer is not const, so
  the runtime copies the data into a temporary space created using the
  given allocator. If the given allocator is a null allocator, this fails.
  @param hostPointer Pointer to host data
  @param r Range of the buffer
  @param propList List of buffer properties
  */
  buffer(const T *hostPointer, const range<dimensions> &r,
         const property_list &propList = {})
      : buffer_mem(detail::clone_data<T, AllocatorT>(AllocatorT(), hostPointer,
                                                     r[0] * r[1] * r[2]),
                   dimensions, r, sizeof(T), pointer_origin::IS_RAW_CONST,
                   detail::make_base_allocator<T, AllocatorT>::get(),
                   propList) {}

  /*!
  @brief Constructs a buffer with host pointer.
  The user has given a const pointer, but the buffer is not const, so
  the runtime copies the data into a temporary space created using the
  given allocator. If the given allocator is a null allocator, this fails.
  @param hostPointer Pointer to host data
  @param r Range of the buffer
  @param allocator The allocator used to create internal storage
  @param propList List of buffer properties
  */
  buffer(const T *hostPointer, const range<dimensions> &r, AllocatorT allocator,
         const property_list &propList = {})
      : buffer_mem(detail::clone_data<T, AllocatorT>(allocator, hostPointer,
                                                     r[0] * r[1] * r[2]),
                   dimensions, r, sizeof(T), pointer_origin::IS_RAW_CONST,
                   detail::make_base_allocator<T, AllocatorT>::get(allocator),
                   propList) {}

  /*!
  @brief Constructs a buffer with a host pointer.
  The user has given a shared pointer, therefore the data is explicitly
  shared between the user and the runtime.
  If the hostPointer is null, no data is copied in, and data is initialized
  inside the runtime. Data is copied out if the reference count of the
  runtime is less than the reference count of the shared pointer.
  @param hostPointer Shared pointer to host data
  @param r Range of the buffer
  @param propList List of buffer properties
  */
  buffer(shared_ptr_class<T> &hostPointer,  // NOLINT(runtime/references)
         const range<dimensions> &r, const property_list &propList = {})
      : buffer_mem(
            hostPointer, dimensions, r, sizeof(T), pointer_origin::IS_SHARED,
            detail::make_base_allocator<T, AllocatorT>::get(), propList) {}

  /*!
  @brief Constructs a buffer with a host pointer.
  The user has given a shared pointer, therefore the data is explicitly
  shared between the user and the runtime.
  If the hostPointer is null, no data is copied in, and data is initialized
  inside the runtime. Data is copied out if the reference count of the
  runtime is less than the reference count of the shared pointer.
  @param hostPointer Shared pointer to host data
  @param r Range of the buffer
  @param allocator The allocator used to create internal storage
  @param propList List of buffer properties
  */
  buffer(shared_ptr_class<T> &hostPointer,  // NOLINT(runtime/references)
         const range<dimensions> &r, AllocatorT allocator,
         const property_list &propList = {})
      : buffer_mem(hostPointer, dimensions, r, sizeof(T),
                   pointer_origin::IS_SHARED,
                   detail::make_base_allocator<T, AllocatorT>::get(allocator),
                   propList) {}

  /*!
  @brief Construct a buffer as a subset from an existing buffer.
  @param b Existing buffer that will act as the parent
  @param base_index Offset of the original data to where the sub-buffer data
             starts
  @param sub_range Range of the original data that will be used in the
             sub-buffer
  */
  buffer(buffer<T, dimensions> &b, const id<dimensions> &base_index,
         const range<dimensions> &sub_range)
      : buffer_mem(b, base_index, sub_range) {}

  /*!
  @brief Construct a buffer from an OpenCL object.
  @param mem_object the user-provided OpenCL object that will be used by the
  buffer
  @param fromQueue the queue holding the context associated with the mem_object
  object
  @param available_event if provided signals that the cl_mem object has been
  created and is ready to be used
  */
  COMPUTECPP_DEPRECATED_API(
      "This constructor is deprecated in SYCL 1.2.1, Please use the OpenCL "
      "interop constructor that accepts a SYCL context instead.")
  buffer(cl_mem mem_object, queue &fromQueue,  // NOLINT(runtime/references)
         event available_event = event())
      : buffer_mem(mem_object, fromQueue, available_event, dimensions,
                   sizeof(T),
                   detail::make_base_allocator<T, AllocatorT>::get()) {}

  /*!
  @brief Construct a buffer from an OpenCL object.
  @brief Construct a buffer from an OpenCL object.
  @param mem_object the user-provided OpenCL object that will be used by the
  buffer
  @param syclContext the context associated with the mem_object object
  @param available_event if provided signals that the cl_mem object has been
  created and is ready to be used
  */
  buffer(cl_mem mem_object,
         const context &syclContext,  // NOLINT(runtime/references)
         event available_event = event())
      : buffer_mem(mem_object, syclContext, available_event, dimensions,
                   sizeof(T),
                   detail::make_base_allocator<T, AllocatorT>::get()) {}

#if COMPUTECPP_OPENGL_INTEROP_AVAILABLE
  /*!
  @brief Constructs an OpenGL interop buffer from the given SYCL context
  with GL interop properties and a GLuint interop
  @param context A context with OpenGL capabilities
  @param GLuint An OpenGL buffer in the given context
  */
  buffer(context &glEnabledContext,  // NOLINT(runtime/references)
         GLuint glInteropBuffer)
      : buffer_mem(glEnabledContext, glInteropBuffer, dimensions, sizeof(T),
                   detail::make_base_allocator<T, AllocatorT>::get()) {
    if (dimensions != 1) {
      COMPUTECPP_ERROR("Only 1D buffers are supported when using GL Interop");
    }
  }
#endif  // COMPUTECPP_OPENGL_INTEROP_AVAILABLE

  /*!
  @brief Constructs a buffer from an std::vector, this is non-standard.
  A shared pointer is created from the raw data of the pointer,
  and a null-deleter is used to avoid the runtime clearing up the
  user-pointer.
  The range of the buffer is extracted from the size of the vector.
  The allocator from the vector is used as an allocator for the buffer.
  @param v Vector to construct the buffer from
  @param propList List of buffer properties
  */
  explicit buffer(vector_class<T> &v,  // NOLINT(runtime/references)
                  const property_list &propList = {})
      : buffer_mem(shared_ptr_class<T>(v.data(), detail::NullDeleter()),
                   dimensions, range<1>(static_cast<unsigned int>(v.size())),
                   sizeof(T), pointer_origin::IS_RAW,
                   detail::make_base_allocator<
                       T, typename std::vector<T>::allocator_type>::get(),
                   propList) {}

  /*!
  @brief Constructs a buffer initialized by the given iterator range.
  This range is read-only, is not written.
  @param begin Iterator starting the range
  @param end  Iterator ending the range
  @param propList List of buffer properties
   */
  template <typename Iterator>
  buffer(Iterator begin, Iterator end, const property_list &propList = {})
      : buffer_mem(detail::clone_data<T, AllocatorT, Iterator>(AllocatorT(),
                                                               begin, end),
                   dimensions, range<1>(std::distance(begin, end)), sizeof(T),
                   pointer_origin::IS_RAW_CONST,
                   detail::make_base_allocator<T, AllocatorT>::get(),
                   propList) {}

  /*!
  @brief Constructs a buffer initialized by the given iterator range.
  This range is read-only, is not written.
  @param begin Iterator starting the range
  @param end  Iterator ending the range
  @param allocator The allocator used to create internal storage
  @param propList List of buffer properties
   */
  template <typename Iterator>
  buffer(Iterator begin, Iterator end, AllocatorT allocator,
         const property_list &propList = {})
      : buffer_mem(
            detail::clone_data<T, AllocatorT, Iterator>(allocator, begin, end),
            dimensions, range<1>(std::distance(begin, end)), sizeof(T),
            pointer_origin::IS_RAW_CONST,
            detail::make_base_allocator<T, AllocatorT>::get(allocator),
            propList) {}

  ~buffer() = default;

  /*!
  @brief Returns an accessor to the buffer, only used on the host side
  @tparam accessMode All access::mode values are accepted
  @return Host accessor
  */
  template <access::mode accessMode>
  accessor<T, dimensions, accessMode, access::target::host_buffer>
  get_access() {
    return accessor<T, dimensions, accessMode, access::target::host_buffer>(
        *this);
  }

  /*!
  @brief this function returns an accessor to the buffer in the given
  command_group
  scope.
  @tparam accessMode all access::mode values are accepted
  @tparam accessTarget defaults to global_buffer, can accept
  global_buffer or constant_buffer
  @param cgh Reference to the command group scope where the accessor is
  requested.
  @return Device accessor
  */
  template <access::mode accessMode,
            access::target accessTarget = access::target::global_buffer>
  accessor<T, dimensions, accessMode, accessTarget> get_access(
      handler &cgh /* NOLINT */) {
    return accessor<T, dimensions, accessMode, accessTarget>(*this, cgh);
  }

  /*!
  @brief Returns an accessor to the buffer in the given
             command_group scope.
  @tparam accessMode All access::mode values are accepted
  @tparam accessTarget Defaults to global_buffer, can accept
             global_buffer or constant_buffer
  @param cgh Reference to the command group scope where the accessor is
             requested.
  @param offset the offset that the accessor will be able to update from.
  @param range the range in which the accessor will be updating the data.
  @return Device accessor
  @deprecated Need to reverse the order of the access offset and range,
              see 4.7.2.1 Buffer Interface in SYCL 1.2.1
  */
  template <access::mode accessMode,
            access::target accessTarget = access::target::global_buffer>
  COMPUTECPP_DEPRECATED_API("Deprecated since SYCL 1.2.1")
  accessor<T, dimensions, accessMode, accessTarget> get_access(
      handler &cgh, id<dimensions> offset,
      range<dimensions> range) {  // NOLINT
    return accessor<T, dimensions, accessMode, accessTarget>(*this, cgh, range,
                                                             offset);
  }

  /**
   * @brief Returns an accessor to the buffer in the given command group scope.
   * @tparam accessMode All access::mode values are accepted
   * @tparam accessTarget Defaults to global_buffer, can accept
   *         global_buffer or constant_buffer
   * @param cgh Reference to the command group scope where the accessor is
   *            requested
   * @param range The range in which the accessor will be updating the data
   * @param offset The offset that the accessor will be able to update from
   * @return Device accessor
   */
  template <access::mode accessMode,
            access::target accessTarget = access::target::global_buffer>
  accessor<T, dimensions, accessMode, accessTarget> get_access(
      handler &cgh, range<dimensions> range, id<dimensions> offset = {}) {
    return accessor<T, dimensions, accessMode, accessTarget>(*this, cgh, range,
                                                             offset);
  }

  /*!
  @brief Returns an accessor to the buffer, only used on the host side
  @tparam accessMode All access::mode values are accepted
  @param offset The offset that the accessor will be able to update from.
  @param range The range in which the accessor will be updating the data.
  @return Host accessor
  @deprecated Need to reverse the order of the access offset and range,
              see 4.7.2.1 Buffer Interface in SYCL 1.2.1
  */
  template <access::mode accessMode>
  COMPUTECPP_DEPRECATED_API("Deprecated since SYCL 1.2.1")
  accessor<T, dimensions, accessMode, access::target::host_buffer> get_access(
      id<dimensions> offset, range<dimensions> range) {
    return accessor<T, dimensions, accessMode, access::target::host_buffer>(
        *this, range, offset);
  }

  /**
   * @brief Returns an accessor to the buffer, only used on the host side
   * @tparam accessMode All access::mode values are accepted
   * @param range The range in which the accessor will be updating the data
   * @param offset The offset that the accessor will be able to update from
   * @return Host accessor
   */
  template <access::mode accessMode>
  accessor<T, dimensions, accessMode, access::target::host_buffer> get_access(
      range<dimensions> range, id<dimensions> offset = {}) {
    return accessor<T, dimensions, accessMode, access::target::host_buffer>(
        *this, range, offset);
  }

  /*! @cond COMPUTECPP_DEV */
  /*!
  @brief Creates a new public buffer object given an internal memory object.
  Implementation only
  */
  explicit buffer(dmem_shptr impl) : buffer_mem(impl) {}
  /*! @endcond */

  /*!
  @brief Returns the range of the buffer.
  */
  cl::sycl::range<dimensions> get_range() const {
    return cl::sycl::range<dimensions>(this->get_range_impl());
  }

  /*!
  @brief Returns whether this SYCL buffer was constructed with the property
             specified by propertyT
  @tparam propertyT Property to check for
  @return True if buffer constructed with the property
  */
  template <typename propertyT>
  bool has_property() const {
    return this->get_properties().template has_property<propertyT>();
  }

  /*!
  @brief Returns a copy of the property of type propertyT that this SYCL
             buffer was constructed with. Throws an error if buffer was not
             constructed with the property.
  @tparam propertyT Property to retrieve
  @return Copy of the property
  */
  template <typename propertyT>
  propertyT get_property() const {
    return this->get_properties().template get_property<propertyT>();
  }

  /*!
  @brief Returns the allocator provided to the buffer
  @return Allocator that was provided to the buffer
  */
  AllocatorT get_allocator() const {
    return detail::cast_base_allocator<AllocatorT>(this->get_base_allocator());
  }

  /*!
  @brief Creates and returns a reinterpreted SYCL buffer with the type
  specified by ReinterpretT, dimensions specified by ReinterpretDim and range
  specified by reinterpretRange
  @tparam ReinterpretT the type that the reinterpreted buffer will use.
  @tparam ReinterpretDim the size used by the reinterpreted buffer.
  @param reinterpretRange the range that the new buffer will use.
  @return the reinterpreted buffer with the requested parameters
  @throw detail::cpp_error_code::INVALID_OBJECT_ERROR (509) if the size of the
  reinterpreted buffer and the size of the original buffer do not match
  */
  template <typename ReinterpretT, int ReinterpretDim>
  buffer<ReinterpretT, ReinterpretDim, AllocatorT> reinterpret(
      range<ReinterpretDim> reinterpretRange) const {
    return buffer<ReinterpretT, ReinterpretDim, AllocatorT>(
        this->reinterpret_buffer(sizeof(ReinterpretT), ReinterpretDim,
                                 reinterpretRange, this->get_impl()));
  }
};

/*!
@brief Specialization for const buffers, that allows the creation of buffers
on the device from const data.
Any allocator, but the map allocator, can be used to create host data.
The allocator must remove the constness of the data in order to create
temporary objects, but host accessors will only be read only always.
*/
template <typename T, int dimensions, typename AllocatorT>
class buffer<const T, dimensions, AllocatorT> : public buffer_mem {
 public:
  /*! @brief Helper for the user, alias for type T */
  using value_type = T;

  /*! @brief Helper for the user, alias for reference to type T */
  using reference = T &;

  /*! @brief Helper for the user, alias for const reference to type T */
  using const_reference = const T &;

  /*! @brief Helper for the user, alias for the type of the allocator */
  using allocator_type = AllocatorT;

  /*!
  @brief Constructs a buffer with host pointer
  @param hostPointer Pointer to host data
  @param r Range of the buffer
  @param propList List of buffer properties
  */
  buffer(const T *hostPointer, const range<dimensions> &r,
         const property_list &propList = {})
      : buffer_mem(detail::clone_data<T, AllocatorT>(AllocatorT(), hostPointer,
                                                     r[0] * r[1] * r[2]),
                   dimensions, r, sizeof(T), pointer_origin::IS_RAW_CONST,
                   detail::make_base_allocator<T, AllocatorT>::get(),
                   propList) {}

  /*!
  @brief Constructs a buffer with host pointer
  @param hostPointer Pointer to host data
  @param r Range of the buffer
  @param allocator The allocator used to create internal storage
  @param propList List of buffer properties
  */
  buffer(const T *hostPointer, const range<dimensions> &r, AllocatorT allocator,
         const property_list &propList = {})
      : buffer_mem(detail::clone_data<T, AllocatorT>(allocator, hostPointer,
                                                     r[0] * r[1] * r[2]),
                   dimensions, r, sizeof(T), pointer_origin::IS_RAW_CONST,
                   detail::make_base_allocator<T, AllocatorT>::get(allocator),
                   propList) {}

  /*!
  @brief Constructs a buffer with a host pointer.
  @param hostPointer Shared pointer to host data
  @param r Range of the buffer
  @param propList List of buffer properties
  */
  buffer(shared_ptr_class<const T> &hostPointer,  // NOLINT(runtime/references)
         const range<dimensions> &r, const property_list &propList = {})
      : buffer_mem(std::const_pointer_cast<T>(hostPointer), dimensions, r,
                   sizeof(T), pointer_origin::IS_SHARED,
                   detail::make_base_allocator<T, AllocatorT>::get(),
                   propList) {}

  /*!
  @brief Constructs a buffer with a host pointer.
  @param hostPointer Shared pointer to host data
  @param r Range of the buffer
  @param allocator The allocator used to create internal storage
  @param propList List of buffer properties
  */
  buffer(shared_ptr_class<const T> &hostPointer,  // NOLINT(runtime/references)
         const range<dimensions> &r, AllocatorT allocator,
         const property_list &propList = {})
      : buffer_mem(std::const_pointer_cast<T>(hostPointer), dimensions, r,
                   sizeof(T), pointer_origin::IS_SHARED,
                   detail::make_base_allocator<T, AllocatorT>::get(allocator),
                   propList) {}

  ~buffer() = default;

  /*!
  @brief this function returns an accessor to the buffer, this is only used on
  the host side
  @tparam accessMode all access::mode values are accepted
  @return Host accessor
  */
  template <access::mode accessMode>
  accessor<const T, dimensions, accessMode, access::target::host_buffer>
  get_access() {
    static_assert((accessMode != access::mode::read_write) &&
                      (accessMode != access::mode::write),
                  "Cannot create a WRITE host accessor from a CONST buffer");
    return accessor<const T, dimensions, accessMode,
                    access::target::host_buffer>(*this);
  }

  /*!
  @brief this function returns an accessor to the buffer in the given
         command_group scope.
  @tparam accessMode all access::mode values are accepted
  @tparam accessTarget defaults to global_buffer, can accept
  global_buffer or constant_buffer
  @param cgh Reference to the command group scope where the accessor is
  requested.
  @return Device accessor
  */
  template <access::mode accessMode,
            access::target accessTarget = access::target::global_buffer>
  accessor<const T, dimensions, accessMode, accessTarget> get_access(
      handler &cgh) {  // NOLINT
    static_assert((accessMode != access::mode::read_write) &&
                      (accessMode != access::mode::write),
                  "Cannot create a WRITE accessor from a CONST buffer");
    return accessor<const T, dimensions, accessMode, accessTarget>(*this, cgh);
  }

  /*!
  @brief this function returns an accessor to the buffer in the given
         command_group scope.
  @tparam accessMode all access::mode values are accepted
  @tparam accessTarget defaults to global_buffer, can accept
  global_buffer or constant_buffer
  @param cgh Reference to the command group scope where the accessor is
  requested.
  @param offset the offset that the accessor will be able to update from.
  @param range the range in which the accessor will be updating the data.
  @return Device accessor
  @deprecated Need to reverse the order of the access offset and range,
              see 4.7.2.1 Buffer Interface in SYCL 1.2.1
  */
  template <access::mode accessMode,
            access::target accessTarget = access::target::global_buffer>
  COMPUTECPP_DEPRECATED_API("Deprecated since SYCL 1.2.1")
  accessor<const T, dimensions, accessMode, accessTarget> get_access(
      handler &cgh, id<dimensions> offset, range<dimensions> range) {  // NOLINT
    static_assert((accessMode != access::mode::read_write) &&
                      (accessMode != access::mode::write),
                  "Cannot create a WRITE accessor from a CONST buffer");
    return accessor<const T, dimensions, accessMode, accessTarget>(
        *this, cgh, range, offset);
  }

  /**
   * @brief Returns an accessor to the buffer in the given command group scope
   * @tparam accessMode All access::mode values are accepted
   * @tparam accessTarget Defaults to global_buffer, can accept
   *                      global_buffer or constant_buffer
   * @param cgh Reference to the command group scope where the accessor is
   *        requested
   * @param range The range in which the accessor will be updating the data
   * @param offset The offset that the accessor will be able to update from
   * @return Device accessor
   */
  template <access::mode accessMode,
            access::target accessTarget = access::target::global_buffer>
  accessor<const T, dimensions, accessMode, accessTarget> get_access(
      handler &cgh, range<dimensions> range, id<dimensions> offset = {}) {
    static_assert((accessMode != access::mode::read_write) &&
                      (accessMode != access::mode::write),
                  "Cannot create a WRITE accessor from a CONST buffer");
    return accessor<const T, dimensions, accessMode, accessTarget>(
        *this, cgh, range, offset);
  }

  /*!
  @brief Returns an accessor to the buffer, only used on the host side
  @tparam accessMode All access::mode values are accepted
  @param offset the offset that the accessor will be able to update from.
  @param range the range in which the accessor will be updating the data.
  @return Device accessor
  @deprecated Need to reverse the order of the access offset and range,
              see 4.7.2.1 Buffer Interface in SYCL 1.2.1
  */
  template <access::mode accessMode>
  COMPUTECPP_DEPRECATED_API("Deprecated since SYCL 1.2.1")
  accessor<T, dimensions, accessMode, access::target::host_buffer> get_access(
      id<dimensions> offset, range<dimensions> range) {
    static_assert((accessMode != access::mode::read_write) &&
                      (accessMode != access::mode::write),
                  "Cannot create a WRITE host accessor from a CONST buffer");
    return accessor<T, dimensions, accessMode, access::target::host_buffer>(
        *this, range, offset);
  }

  /**
   * @brief Returns an accessor to the buffer, only used on the host side
   * @tparam accessMode All access::mode values are accepted
   * @param range the range in which the accessor will be updating the data
   * @param offset the offset that the accessor will be able to update from
   * @return Host accessor
   */
  template <access::mode accessMode>
  accessor<T, dimensions, accessMode, access::target::host_buffer> get_access(
      range<dimensions> range, id<dimensions> offset = {}) {
    static_assert((accessMode != access::mode::read_write) &&
                      (accessMode != access::mode::write),
                  "Cannot create a WRITE host accessor from a CONST buffer");
    return accessor<T, dimensions, accessMode, access::target::host_buffer>(
        *this, range, offset);
  }

  explicit buffer(dmem_shptr impl) : buffer_mem(impl) {}

  /*!
  @brief Returns whether this SYCL buffer was constructed with the property
         specified by propertyT
  @tparam propertyT Property to check for
  @return True if buffer constructed with the property
  */
  template <typename propertyT>
  bool has_property() const {
    return this->get_properties().template has_property<propertyT>();
  }

  /*!
  @brief Returns a copy of the property of type propertyT that this SYCL
         buffer was constructed with. Throws an error if buffer was not
         constructed with the property.
  @tparam propertyT Property to retrieve
  @return Copy of the property
  */
  template <typename propertyT>
  propertyT get_property() const {
    return this->get_properties().template get_property<propertyT>();
  }

  /*!
  @brief Returns the allocator provided to the buffer
  @return Allocator that was provided to the buffer
  */
  AllocatorT get_allocator() const {
    return detail::cast_base_allocator<AllocatorT>(this->get_base_allocator());
  }

  /*!
  @brief Creates and returns a reinterpreted SYCL buffer with the type
  specified by ReinterpretT, dimensions specified by ReinterpretDim and range
  specified by reinterpretRange
  @tparam ReinterpretT the type that the reinterpreted buffer will use.
  @tparam ReinterpretDim the size used by the reinterpreted buffer.
  @param reinterpretRange the range that the new buffer will use.
  @return the reinterpreted buffer with the requested parameters
  @throw cl::sycl::invalid_object_error if the size of the reinterpreted
  buffer and the size of the original buffer do not match
  */
  template <typename ReinterpretT, int ReinterpretDim>
  buffer<ReinterpretT, ReinterpretDim, AllocatorT> reinterpret(
      range<ReinterpretDim> reinterpretRange) const {
    return buffer<ReinterpretT, ReinterpretDim, AllocatorT>(
        this->reinterpret_buffer(sizeof(ReinterpretT), reinterpretRange,
                                 this->get_impl()));
  }
};

}  // namespace sycl
}  // namespace cl

namespace std {
/*!
@brief provides a specialization for std::hash for the buffer class. An
std::hash<std::shared_ptr<...>> object is created and its function call
operator is used to hash the contents of the shared_ptr. The returned hash is
actually the result of (size_t) object.get_impl().get()
*/
template <typename T, int dimensions, typename AllocatorT>
struct hash<cl::sycl::buffer<T, dimensions, AllocatorT>> {
 public:
  /*!
  @brief enables calling an std::hash object as a function with the object to be
  hashed as a parameter
  @param object the object to be hashed
  @tparam std the std namespace where this specialization resides
  */
  size_t operator()(
      const cl::sycl::buffer<T, dimensions, AllocatorT> &object) const {
    hash<cl::sycl::dmem_shptr> hasher;
    return hasher(object.get_impl());
  }
};
}  // namespace std
////////////////////////////////////////////////////////////////////////////////

#endif  // RUNTIME_INCLUDE_SYCL_BUFFER_H_

////////////////////////////////////////////////////////////////////////////////
