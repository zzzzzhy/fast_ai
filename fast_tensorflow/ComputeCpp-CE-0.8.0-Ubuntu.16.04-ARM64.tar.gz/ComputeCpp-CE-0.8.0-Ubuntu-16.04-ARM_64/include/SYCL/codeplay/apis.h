/******************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file apis.h

  @brief This file contains Codeplay specific extensions to the SYCL API
*/
#ifndef RUNTIME_INCLUDE_SYCL_CODEPLAY_APIS_H_
#define RUNTIME_INCLUDE_SYCL_CODEPLAY_APIS_H_

#include "SYCL/apis.h"
#include "SYCL/common.h"

namespace cl {
namespace sycl {

namespace codeplay {

#ifndef __SYCL_DEVICE_ONLY__

/**
  @brief Command group host handler that implements Codeplay specific API
  extensions
*/
class COMPUTECPP_EXPORT host_handler {
 public:
  friend class queue;
  friend class detail::queue;

 protected:
  /**
  * @brief Creates a handler for a specific queue.
  */
  explicit host_handler(const dqueue_shptr &q,
                        const dqueue_shptr &fallbackQueue = nullptr)
      : cgh(q, fallbackQueue) {}

 public:
  operator cl::sycl::handler &() { return cgh; }
  operator const cl::sycl::handler &() const { return cgh; }

  /// @cond COMPUTECPP_DEV

  /*!
   * @brief Returns an internal transaction
   */
  detail::transaction *get_transaction() const;

  /// COMPUTECPP_DEV @endcond

  /////////////// API : Host Task

  /*!
    @brief This function effectively just launches a single thread
    to execute the kernel in serial asynchronously to the host execution.
    @tparam functorT this is the type of the kernel. It will be automatically
    deduced by the compiler
    @param functor the kernel being enqueued
  */
  template <typename functorT>
  void host_task(const functorT &functor) {
    this->host_task_impl(functor);
  }

 protected:
  void host_task_impl(const detail::single_task_ptr &singleTaskPtr);

  cl::sycl::handler cgh;

};  // class host_handler

#else  // __SYCL_DEVICE_ONLY__

class host_handler {
 public:
  explicit host_handler(dqueue_shptr q) : cgh(q) {}

  operator cl::sycl::handler &() { return cgh; }
  operator const cl::sycl::handler &() const { return cgh; }

  /////////////// API : Host Task

  template <typename functorT>
  void host_task(const functorT &functor) {
    // No work for the device compiler
  }

 protected:
  cl::sycl::handler cgh;

};  // class host_handler

#endif  // __SYCL_DEVICE_ONLY__

}  // namespace codeplay
}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_CODEPLAY_APIS_H_
