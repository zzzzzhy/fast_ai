////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2002-2018 Codeplay Software Limited
//  All Rights Reserved.
//
//  ComputeCpp : SYCL 1.2 Implementation
//
//  File: pointer_mapper.h
//
////////////////////////////////////////////////////////////////////////////////

#ifndef RUNTIME_INCLUDE_SYCL_CODEPLAY_POINTER_MAPPER_H
#define RUNTIME_INCLUDE_SYCL_CODEPLAY_POINTER_MAPPER_H

#include "SYCL/common.h"

namespace cl {
namespace sycl {
namespace codeplay {

/**
 * Forward declaration.
 * Implemented in the sdk.
 */
class PointerMapper;
}  // namespace codeplay

namespace detail {
/**
 * @brief Registers a pointer to a pointer mapper object in the ComputeCpp
 * Runtime.
 *        Implemented in the ComputeCpp Runtime library.
 * @param pointerMapper a pointer to a pointer mapper
 */
void register_pointer_mapper(codeplay::PointerMapper* pointerMapper);

/**
 * @brief Returns the pointer to the pointer mapper registered in the ComputeCpp
 * Runtime.
 *        Implemented in the ComputeCpp Runtime library.
 * @return The pointer to the pointer mapper
 */
codeplay::PointerMapper* get_pointer_mapper();

}  // namespace detail
}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_CODEPLAY_POINTER_MAPPER_H
