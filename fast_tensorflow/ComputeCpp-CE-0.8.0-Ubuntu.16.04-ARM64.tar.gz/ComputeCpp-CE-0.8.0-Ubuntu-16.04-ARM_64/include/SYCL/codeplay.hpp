/******************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file codeplay.hpp

  @brief This file includes all Codeplay extension files
*/
#ifndef RUNTIME_INCLUDE_SYCL_CODEPLAY_HPP_
#define RUNTIME_INCLUDE_SYCL_CODEPLAY_HPP_

#include "SYCL/codeplay/apis.h"
#include "SYCL/codeplay/pointer_mapper.h"

#endif  // RUNTIME_INCLUDE_SYCL_CODEPLAY_HPP_
