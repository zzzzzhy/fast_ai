/******************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file apis.h

  @brief This file contains functions that are used to invoke kernels
*/
#ifndef RUNTIME_INCLUDE_SYCL_APIS_H_
#define RUNTIME_INCLUDE_SYCL_APIS_H_

#include "SYCL/accessor_base.h"
#include "SYCL/buffer.h"
#include "SYCL/common.h"
#include "SYCL/group.h"
#include "SYCL/index_array_operators.h"
#include "SYCL/kernel.h"
#include "SYCL/predefines.h"
#include "SYCL/program.h"
#include "SYCL/task.h"
#include <algorithm>
#include <iterator>

namespace cl {
namespace sycl {
namespace detail {

class enqueue_device_kernel_command;

/*
@brief Given a lambda and a template parameter with a name,
creates a typedef which will define the kernel name used
by the device compiler.
*/
template <typename functorT, typename nameT>
struct enable_functor {
  typedef nameT kernel_name;
};

/*! enable_functor.
@brief Specialization of the enable_functor for when
the user passes a functor. This way, the kernel name is not defined if the user
has given a functor (as the name of the kernel is the name of the functor).
*/
template <typename functorT>
struct enable_functor<functorT, std::nullptr_t> {
  typedef functorT kernel_name;
};

/**
 * @brief Forward declaration of the helper struct for handler::set_args
 */
template <typename CurrentT, typename... Ts>
struct set_args_helper;

}  // namespace detail

namespace codeplay {
class host_handler;
}

}  // namespace sycl
}  // namespace cl

#ifndef __SYCL_DEVICE_ONLY__

namespace cl {
namespace sycl {

/*!
@brief A handler gives user access to command group scope functionality,
such as API calls. This simplifies the interface, as the command
group class is not required anymore and the scope is explicit for
accessors and API entries.

It is also used by accessors to get the current command group scope.
Handlers can only be constructed from within queues.
For the time being, the deprecated command group function
also can create handlers.

The templated-side of the API entries is defined here.
Some API entries are explicitly deleted to shield users from weird
template errors caused by enable_if macros. In particular,
if there is a pointer to a kernel instead of a kernel, the template
deduction fails and causes a massive template error. However, using
the deleted API entry the user sees an explicit error because they are
using a non-valid interface.
*/
class COMPUTECPP_EXPORT handler {
  /*!
  @brief Maximum number of kernels that a command group can contain.
  Implementation and specification currently only support a single
  kernel.
  */
  const unsigned MAX_KERNELS_PER_CG = 1u;

  friend class queue;
  friend class detail::queue;
  friend class codeplay::host_handler;

  /*!
   @brief Type of a function that sets a parameter to a kernel.
  */
  typedef function_class<void(kernel &, handler &)> add_param_func_t;

  /*!
  @brief Sets the current list of parameters to the given kernel.
  */
  void set_parameters(kernel &syclKernel);

  /*!
  @brief Gets the parameters from a functor and set them as OpenCL parameters.
  @tparam functorT Functor
  @param cl::sycl::kernel SYCL Kernel associated with the functor
  @param currentCommand Internal command object
  */
  template <typename kernelName, typename functorT>
  inline void process_functor_arguments(
      const functorT &functor,
      cl::sycl::kernel &syclKernel,  // NOLINT
      detail::enqueue_device_kernel_command *currentCommand) {
    using std::begin;

    // The copy is required to avoid breaking the strict aliasing rule
    // Once the device compiler emits stub files with an enum, the static_cast
    // from int to an enum can be deleted
    auto const param_kinds = [&] {
      using kind_type =
          decltype(*detail::kernel_info<kernelName>::kind_begin());
      vector_class<detail::parameter_kind> result(
          detail::kernel_info<kernelName>::arg_size);
      std::transform(
          detail::kernel_info<kernelName>::kind_begin(),
          detail::kernel_info<kernelName>::kind_end(), begin(result),
          [](kind_type k) { return static_cast<detail::parameter_kind>(k); });
      return result;
    }();
    auto const param_classes = [&] {
      using class_type =
          decltype(*detail::kernel_info<kernelName>::class_begin());
      vector_class<detail::parameter_class> result(
          detail::kernel_info<kernelName>::arg_size);
      std::transform(
          detail::kernel_info<kernelName>::class_begin(),
          detail::kernel_info<kernelName>::class_end(), begin(result),
          [](class_type c) { return static_cast<detail::parameter_class>(c); });
      return result;
    }();

    auto functorBuffer = reinterpret_cast<detail::binary_address>(&functor);
    auto SI = detail::kernel_info<kernelName>::size_begin();
    auto SE = detail::kernel_info<kernelName>::size_end();
    auto OI = detail::kernel_info<kernelName>::offset_begin();
    auto OE = detail::kernel_info<kernelName>::offset_end();
    auto KI = param_kinds.data();
    auto KE = KI + param_kinds.size();
    auto CI = param_classes.data();
    auto CE = CI + param_classes.size();
    auto UI = detail::kernel_info<kernelName>::used_begin();
    auto UE = detail::kernel_info<kernelName>::used_end();
    process_functor_arguments_impl(syclKernel, functorBuffer, SI, SE, OI, OE,
                                   KI, KE, CI, CE, UI, UE, currentCommand);
  }

 public:
  /*!
  @brief Destructor of the handler, implementation on the cpp file
  so the default_deleter can see the implementation of the internal
  transaction object.
  */
  COMPUTECPP_TEST_VIRTUAL ~handler();
  /*! @cond COMPUTECPP_DEV */
  /*!
  @brief Returns an internal transaction
  */
  detail::transaction *get_transaction() const;

  /*!
  @brief Returns an internal transaction only
  */
  dtrans_uptr &&move_transaction();

  /*! @endcond */
  /*!
  @brief Sets an argument when using interop kernels
  */
  template <typename T>
  void set_arg(int param_num, T &&param) {
    if (m_paramVec.size() <= static_cast<unsigned int>(param_num)) {
      m_paramVec.resize(param_num + 1);
    }

    add_param_func_t pf = [param_num, param](kernel &k, handler &h) {
      k.set_arg(param_num, param, h);
    };

    m_paramVec[param_num] = pf;
  }

  /**
   * @brief Set all the given kernel args arguments for an OpenCL kernel,
   *        as if set_arg() was used with each of them in the same order
   *        and increasing index always starting at 0.
   * @tparam Ts Types of the parameters passed to the OpenCL kernel
   * @param args Parameters passed to the OpenCL kernel
   */
  template <typename... Ts>
  void set_args(Ts &&... args) {
    detail::set_args_helper<Ts...>::apply(*this, 0, std::forward<Ts>(args)...);
  }

  /////////////// API : Single Task

  /*!
  @brief This function effectively just launches a single thread
  to execute the kernel in serial asynchronously to the host execution.
  This function takes in a precompiled kernel @ref syclKernel previously
  created using @ref build_with_kernel_type or @ref compile_with_kernel_type
  @param syclKernel The precompiled kernel to be enqueued
  */
  void single_task(kernel syclKernel);

  /*! @cond COMPUTECPP_DEV */
  void single_task(kernel *syclKernel) = delete;

  template <typename kernelName, typename functorT>
  void single_task_impl(const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    program p(
        program::create_program_for_kernel<kernelName>(this->get_context()));
    kernel syclKernel(p.get_kernel<kernelName>());

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    this->execute_kernel_single_task_ptr(
        nd_range<3>(range<3>(1, 1, 1), range<3>(1, 1, 1), id<3>()), syclKernel,
        functor, currentCommand);
  }

  template <typename kernelName, typename functorT>
  void single_task_impl(kernel syclKernel, const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);
    this->execute_kernel_single_task_ptr(
        nd_range<3>(range<3>(1, 1, 1), range<3>(1, 1, 1), id<3>()), syclKernel,
        functor, currentCommand);
  }
  /*! @endcond */

  /*!
  @brief This function effectively just launches a single thread
  to execute the kernel in serial asynchronously to the host execution.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT>
  void single_task(const functorT &functor) {
    single_task_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  /*!
  @brief This function effectively just launches a single thread
  to execute the kernel in serial asynchronously to the host execution.
  This function takes in a precompiled kernel @ref syclKernel previously
  created using @ref build_with_kernel_type or @ref compile_with_kernel_type
  @tparam nameT The name of the kernel being enqueued
  @param syclKernel The precompiled kernel to be enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT>
  void single_task(kernel syclKernel, const functorT &functor) {
    single_task_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(syclKernel, functor);
  }

  /////////////// API : Parallel For

  /*!
  @brief Parallel_for will enqueue the precompiled kernel @ref syclKernel to be
  executed
  a number of instances working in parallel over the number of local and global
  work items specified
  by @ref ndRange.
  @tparam dimensions Number of dimensions of the kernel
  @param ndRange Dimensions of the global and local work groups
  @param syclKernel The precompiled kernel to be enqueued
  */
  template <int dimensions>
  void parallel_for(const nd_range<dimensions> &ndRange, kernel syclKernel) {
    this->parallel_for_impl(static_cast<const detail::nd_range_base &>(ndRange),
                            syclKernel);
  }

  /*!
  @brief Parallel_for will enqueue the precompiled kernel @ref syclKernel to be
  executed a number of
  instances working in parallel over the number of global work items specified
  by @ref range.
  @tparam dimensions Number of dimensions of the kernel
  @param range Dimensions of the global work group
  @param syclKernel The precompiled kernel to be enqueued
  */
  template <int dimensions>
  void parallel_for(const range<dimensions> &range, kernel syclKernel) {
    this->parallel_for_impl(static_cast<const detail::index_array &>(range),
                            detail::index_array(0, 0, 0), syclKernel);
  }

  /*!
  @brief Parallel_for will enqueue the precompiled kernel @ref syclKernel to be
  executed a number of
  instances working in parallel over the number of global work items specified
  by @ref range.
  @tparam dimensions Number of dimensions of the kernel
  @param range Dimensions of the global work group
  @param offset The offset into the data being executed
  @param syclKernel The precompiled kernel to be enqueued
  */
  template <int dimensions>
  void parallel_for(const range<dimensions> &range, id<dimensions> offset,
                    kernel syclKernel) {
    this->parallel_for_impl(static_cast<const detail::index_array &>(range),
                            static_cast<const detail::index_array &>(offset),
                            syclKernel);
  }

  /*! @cond COMPUTECPP_DEV */

  template <int dimensions>
  void parallel_for(const range<dimensions> &range,
                    kernel *syclKernel) = delete;
  template <int dimensions>
  void parallel_for(const range<dimensions> &range, id<dimensions> offset,
                    kernel *syclKernel) = delete;

  template <int dimensions>
  void parallel_for(const nd_range<dimensions> &ndRange,
                    kernel *syclKernel) = delete;

  void parallel_for_impl(const detail::index_array &range, kernel syclKernel);

  void parallel_for_impl(const detail::index_array &range,
                         const detail::index_array &offset, kernel syclKernel);

  void parallel_for_impl(const detail::nd_range_base &ndRange,
                         kernel syclKernel);

  template <typename kernelName, typename functorT>
  void parallel_for_impl(const detail::nd_range_base &ndRange,
                         const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    program p(
        program::create_program_for_kernel<kernelName>(this->get_context()));
    kernel syclKernel(p.get_kernel<kernelName>());

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    this->execute_kernel_parallel_for_ptr(ndRange, syclKernel, functor,
                                          currentCommand);
  }

  template <typename kernelName, typename functorT>
  void parallel_for_impl(kernel syclKernel,
                         const detail::nd_range_base &ndRange,
                         const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    this->execute_kernel_parallel_for_ptr(ndRange, syclKernel, functor,
                                          currentCommand);
  }

  void parallel_for_impl(const detail::nd_range_base &ndRange,
                         kernel syclKernel,
                         detail::enqueue_device_kernel_command *currentCommand);

  /*! COMPUTECPP_DEV @endcond */

  /*!
  @brief Parallel_for will enqueue the kernel @ref functor to be executed a
  number of
  instances working in parallel over the number of local and global work items
  specified
  by @ref ndRange.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param ndRange Dimensions of the global and local work groups
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(const nd_range<dimensions> &ndRange,
                    const functorT &functor) {
    parallel_for_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(ndRange, functor);
  }

  /*!
  @brief Parallel_for will enqueue the kernel @ref functor to be executed a
  number of
  instances working in parallel over the number of local and global work items
  specified
  by @ref ndRange.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param syclKernel The precompiled kernel to be enqueued
  @param ndRange Dimensions of the global and local work groups
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(kernel syclKernel, const nd_range<dimensions> &ndRange,
                    const functorT &functor) {
    parallel_for_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(syclKernel, ndRange, functor);
  }

  /* @cond COMPUTECPP_DEV*/

  template <typename kernelName, typename functorT>
  void parallel_for_impl(kernel syclKernel, const detail::index_array &range,
                         const detail::index_array &globalOffset,
                         const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    detail::nd_range_base ndRange(range, globalOffset);

    this->execute_kernel_parallel_for_id_ptr(ndRange, syclKernel, functor,
                                             currentCommand);
  }

  template <typename kernelName, typename functorT>
  void parallel_for_impl(const detail::index_array &range,
                         const detail::index_array &globalOffset,
                         const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    program p(
        program::create_program_for_kernel<kernelName>(this->get_context()));

    kernel syclKernel(p.get_kernel<kernelName>());

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    detail::nd_range_base ndRange(range, globalOffset);

    this->execute_kernel_parallel_for_id_ptr(ndRange, syclKernel, functor,
                                             currentCommand);
  }
  /* @endcond */

  /*!
  @brief Parallel_for will enqueue the kernel @ref functor to be executed a
  number of
  instances working in parallel over the number of global work items specified
  by @ref range.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param range Dimensions of the global work group
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(const range<dimensions> &range, const functorT &functor) {
    parallel_for_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(range, detail::index_array(0, 0, 0), functor);
  }

  /*!
  @brief Parallel_for will enqueue the kernel @ref functor to be executed a
  number of
  instances working in parallel over the number of global work items specified
  by @ref range.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param range Dimensions of the global work group
  @param offset The offset into the data being executed
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(const range<dimensions> &range,
                    const id<dimensions> &offset, const functorT &functor) {
    parallel_for_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(range, offset, functor);
  }

  /*!
  @brief Parallel_for will enqueue the precompiled kernel @ref syclKernel to be
  executed a number of
  instances working in parallel over the number of global work items specified
  by @ref range.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param syclKernel The precompiled kernel which is being run
  @param range Dimensions of the global work group
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(kernel syclKernel, const range<dimensions> &range,
                    const functorT &functor) {
    parallel_for_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(syclKernel, range, detail::index_array(0, 0, 0), functor);
  }

  /*!
  @brief Parallel_for will enqueue the precompiled kernel @ref syclKernel to be
  executed a number of
  instances working in parallel over the number of global work items specified
  by @ref range.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param syclKernel The precompiled kernel which is being run
  @param range Dimensions of the global work group
  @param offset The offset into the data being executed
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(kernel syclKernel, const range<dimensions> &range,
                    const id<dimensions> &offset, const functorT &functor) {
    parallel_for_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(syclKernel, range, offset, functor);
  }

  /////////////// API : Hierarchical

  /*!
  @brief parallel_for_work_group will enqueue the precompiled kernel @ref
  syclKernel to
  be executed a number of instances working in parallel over the number of local
  and global work items specified by @ref numGroups.
  @tparam dimensions Number of dimensions of the kernel
  @param numGroups Dimensions of the global and local work groups
  @param syclKernel The precompiled kernel which is being run
  */
  template <int dimensions>
  void parallel_for_work_group(const range<dimensions> &numGroups,
                               kernel syclKernel) {
    this->parallel_for_work_group_impl(
        static_cast<const detail::index_array &>(numGroups), syclKernel);
  }

  /*! @cond COMPUTECPP_DEV*/

  void parallel_for_work_group_impl(const detail::index_array &numGroups,
                                    kernel syclKernel);

  // Explicitly disable the * version to avoid unreadable errors.
  template <int dimensions>
  void parallel_for_work_group(const range<dimensions> &numGroups,
                               kernel *syclKernel) = delete;

  // Explicitly disable the * version to avoid unreadable errors.
  template <int dimensions>
  void parallel_for_work_group(const range<dimensions> &numGroups,
                               const range<dimensions> &groupSize,
                               kernel *syclKernel) = delete;

  template <typename kernelName, typename functorT>
  void parallel_for_work_group_impl(const detail::index_array &numGroups,
                                    const detail::index_array &groupSize,
                                    const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    detail::nd_range_base ndRange(numGroups * groupSize, groupSize,
                                  detail::index_array(0, 0, 0));
    program p(
        program::create_program_for_kernel<kernelName>(this->get_context()));

    kernel syclKernel(p.get_kernel<kernelName>());

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    this->execute_kernel_parallel_for_work_group_ptr(ndRange, syclKernel,
                                                     functor, currentCommand);
  }

  template <typename kernelName, typename functorT>
  void parallel_for_work_group_impl(kernel syclKernel,
                                    const detail::index_array &numGroups,
                                    const detail::index_array &groupSize,
                                    const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    detail::nd_range_base ndRange(numGroups * groupSize, groupSize,
                                  detail::index_array(0, 0, 0));

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    this->execute_kernel_parallel_for_work_group_ptr(ndRange, syclKernel,
                                                     functor, currentCommand);
  }

  template <typename kernelName, typename functorT>
  void parallel_for_work_group_impl(const detail::index_array &numGroups,
                                    const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    program p(
        program::create_program_for_kernel<kernelName>(this->get_context()));

    kernel syclKernel(p.get_kernel<kernelName>());

    detail::index_array groupSize = get_optimal_workgroup_size(syclKernel);
    detail::nd_range_base ndRange(numGroups * groupSize, groupSize,
                                  detail::index_array(0, 0, 0));

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    this->execute_kernel_parallel_for_work_group_ptr(ndRange, syclKernel,
                                                     functor, currentCommand);
  }

  template <typename kernelName, typename functorT>
  void parallel_for_work_group_impl(kernel syclKernel,
                                    const detail::index_array &numGroups,
                                    const functorT &functor) {
    auto currentCommand = this->create_kernel_command_group();

    detail::index_array groupSize = get_optimal_workgroup_size(syclKernel);
    detail::nd_range_base ndRange(numGroups * groupSize, groupSize,
                                  detail::index_array(0, 0, 0));

    this->process_functor_arguments<kernelName, functorT>(functor, syclKernel,
                                                          currentCommand);

    this->execute_kernel_parallel_for_work_group_ptr(ndRange, syclKernel,
                                                     functor, currentCommand);
  }
  /* @endcond */

  /*!
  @brief parallel_for_work_group will enqueue the precompiled kernel @ref
  syclKernel to
  be executed a number of instances working in parallel over the number of local
  and global
  work items specified by @ref range.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param syclKernel The precompiled kernel which is being run
  @param range Dimensions of the global work groups
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(kernel syclKernel,
                               const range<dimensions> &range,
                               const functorT &functor) {
    parallel_for_work_group_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(syclKernel, range, functor);
  }

  /*!
  @brief parallel_for_work_group will enqueue the kernel @ref functor to
  be executed a number of instances working in parallel over the number of local
  and global
  work items specified by @ref range.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param range Dimensions of the global and local work groups
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(const range<dimensions> &range,
                               const functorT &functor) {
    parallel_for_work_group_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(range, functor);
  }

  /*!
  @brief parallel_for_work_group will enqueue the precompiled kernel @ref
  syclKernel to
  be executed a number of instances working in parallel over the number of local
  and global
  work items specified by @ref numGroups and @ref groupSize.
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param syclKernel The precompiled kernel which is being run
  @param numGroups dimensions of the work groups being launched
  @param groupSize each work group will launch work-items of dimension of
  groupSize  @tparam nameT The name of the kernel being enqueued
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(const range<dimensions> &numGroups,
                               const range<dimensions> &groupSize,
                               const functorT &functor) {
    parallel_for_work_group_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(numGroups, groupSize, functor);
  }

  /*!
  @brief parallel_for_work_group will enqueue the precompiled kernel @ref
  syclKernel to
  be executed a number of instances working in parallel over the number of local
  and global
  work items specified by @ref numGroups and @ref groupSize.
  @tparam nameT The name of the kernel being enqueued
  @tparam functorT This is the type of the kernel. It will be automatically
  deduced by the compiler
  @tparam dimensions Number of dimensions of the kernel
  @param syclKernel The precompiled kernel which is being run
  @param numGroups dimensions of the work groups being launched
  @param groupSize each work group will launch work-items of dimension of
  groupSize
  @param functor The kernel being enqueued
  */
  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(kernel syclKernel,
                               const range<dimensions> &numGroups,
                               const range<dimensions> &groupSize,
                               const functorT &functor) {
    parallel_for_work_group_impl<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(syclKernel, numGroups, groupSize, functor);
  }

  /* @cond COMPUTECPP_DEV*/
  /** get_num_kernels.
   * Gets the number of kernels in the current command group.
   */
  unsigned get_num_kernels() const;
  /* @endcond */

  /**
    @brief Function that registers a placeholder accessor with the handler.
    Defined in Codeplay Extension CP004.
    @param acc Placeholder accessor
  */
  template <typename elemT, int kDims, access::mode kMode,
            access::target kTarget>
  void require(const accessor<elemT, kDims, kMode, kTarget,
                              access::placeholder::true_t> &acc) {
    require(static_cast<const accessor_base &>(acc));
  }

  /**
    @brief Function that registers a placeholder accessor with the handler
    and the associated storage.
    Defined in Codeplay Extension CP004.
    Will fail if accessor already associated with storage.
    @param buf Buffer object
    @param acc Placeholder accessor
  */
  template <typename elemT, int kDims, access::mode kMode,
            access::target kTarget>
  void require(buffer<elemT, kDims> &bufObj,
               const accessor<elemT, kDims, kMode, kTarget,
                              access::placeholder::true_t> &acc) {
    require(static_cast<const accessor_base &>(acc), bufObj.get_impl());
  }

  /////////////// API : Copy from/to/in device

  /**
    @brief Copies the data from the device accessor to the host pointer.
           hostPtr must have enough space allocated to match the size of the
           accessor data.

           The underlying type of the accessor and the host pointer must match
           - Accessor type can be const
           - At least one type is allowed to be void
    @tparam TAcc Underlying type of the data associated with the accessor
    @tparam THostPtr Underlying type of the host pointer data
    @tparam dims Number of dimensions of the accessor
    @tparam accessMode Access mode of the accessor
    @tparam accessTarget Access target of the accessor
    @tparam isPlaceholder Whether the accessor is a placeholder
    @tparam COMPUTECPP_ENABLE_IF The function is only valid when the access mode
            includes read access
    @param acc Accessor that is used to access the buffer or image
    @param hostPtr Host pointer that will be updated
  */
  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<TAcc, THostPtr>::value &&
                       detail::is_read_mode<accessMode>::value))>
  void copy(accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc,
            shared_ptr_class<THostPtr> hostPtr) {
    auto &&hostPtrVoid = std::static_pointer_cast<void>(hostPtr);
    this->update_device_data(acc, hostPtrVoid, cl::sycl::access::mode::read,
                             true);
  }

  /**
    @brief Copies the data from the host pointer to the device accessor.
           hostPtr must have enough space allocated to match the size of the
           accessor data.

           The underlying type of the host pointer and the accessor must match
           - Host pointer type can be const
           - At least one type is allowed to be void
    @tparam THostPtr Underlying type of the host pointer data
    @tparam TAcc Underlying type of the data associated with the accessor
    @tparam dims Number of dimensions of the accessor
    @tparam accessMode Access mode of the accessor
    @tparam accessTarget Access target of the accessor
    @tparam isPlaceholder Whether the accessor is a placeholder
    @tparam COMPUTECPP_ENABLE_IF The function is only valid when the access mode
            includes write access
    @param hostPtr Host pointer that points to the new data
    @param acc Accessor that is used to access the buffer or image
  */
  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<THostPtr, TAcc>::value &&
                       detail::is_write_mode<accessMode>::value))>
  void copy(shared_ptr_class<THostPtr> hostPtr,
            accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc) {
    auto &&hostPtrVoid = std::static_pointer_cast<void>(
        std::const_pointer_cast<typename std::remove_const<THostPtr>::type>(
            hostPtr));
    this->update_device_data(acc, hostPtrVoid, cl::sycl::access::mode::write,
                             true);
  }

  /**
    @brief Copies the data from the device accessor to the host pointer.
           hostPtr must have enough space allocated to match the size of the
           accessor data.

           The underlying type of the accessor and the host pointer must match
           - Accessor type can be const
           - At least one type is allowed to be void
    @tparam TAcc Underlying type of the data associated with the accessor
    @tparam THostPtr Underlying type of the host pointer data
    @tparam dims Number of dimensions of the accessor
    @tparam accessMode Access mode of the accessor
    @tparam accessTarget Access target of the accessor
    @tparam isPlaceholder Whether the accessor is a placeholder
    @tparam COMPUTECPP_ENABLE_IF The function is only valid when the access mode
            includes read access
    @param acc Accessor that is used to access the buffer or image
    @param hostPtr Host pointer that will be updated
  */
  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<TAcc, THostPtr>::value &&
                       detail::is_read_mode<accessMode>::value))>
  void copy(accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc,
            THostPtr *hostPtr) {
    auto hostPtrVoid = shared_ptr_class<void>(static_cast<void *>(hostPtr),
                                              detail::NullDeleter());
    this->update_device_data(acc, hostPtrVoid, cl::sycl::access::mode::read,
                             true);
  }

  /**
    @brief Copies the data from the host pointer to the device accessor.
           hostPtr must have enough space allocated to match the size of the
           accessor data.

           The underlying type of the host pointer and the accessor must match
           - Host pointer type can be const
           - At least one type is allowed to be void
    @tparam THostPtr Underlying type of the host pointer data
    @tparam TAcc Underlying type of the data associated with the accessor
    @tparam dims Number of dimensions of the accessor
    @tparam accessMode Access mode of the accessor
    @tparam accessTarget Access target of the accessor
    @tparam isPlaceholder Whether the accessor is a placeholder
    @tparam COMPUTECPP_ENABLE_IF The function is only valid when the access mode
            includes write access
    @param hostPtr Host pointer that points to the new data
    @param acc Accessor that is used to access the buffer or image
  */
  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<THostPtr, TAcc>::value &&
                       detail::is_write_mode<accessMode>::value))>
  void copy(const THostPtr *hostPtr,
            accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc) {
    auto hostPtrVoid = shared_ptr_class<void>(
        static_cast<void *>(const_cast<THostPtr *>(hostPtr)),
        detail::NullDeleter());
    this->update_device_data(acc, hostPtrVoid, cl::sycl::access::mode::write,
                             true);
  }

  /**
    @brief Copies data associated with the origin accessor to the data
           associated with the destination accessor.

           There are a few restrictions on the accessors:
           - The underlying type and number of dimensions must match
             - Origin type can be const
           - The origin accessor access mode must include read access
           - The destination accessor access mode must include write access
           - The size of the destination accessor data must be enough to hold
             the data from the origin accessor
    @tparam TOrig Underlying type of the data associated with the origin
            accessor
    @tparam TDest Underlying type of the data associated with the destination
            accessors
    @tparam dims Number of dimensions of the accessor
    @tparam accessModeOrig Access mode of the origin accessor
    @tparam accessModeDest Access mode of the destination accessor
    @tparam accessTargetOrig Access target of the origin accessor
    @tparam accessTargetDest Access target of the destination accessor
    @tparam isPlaceholder Whether the origin accessor is a placeholder
    @tparam isPlaceholder Whether the destination accessor is a placeholder
    @tparam COMPUTECPP_ENABLE_IF Checks that the accessor types conform to the
            restrictions.
    @param originAcc Accessor with the data that will be copied from
    @param destinationAcc Accessor with the data that will be copied to
  */
  template <typename TOrig, typename TDest, int dims,
            cl::sycl::access::mode accessModeOrig,
            cl::sycl::access::mode accessModeDest,
            cl::sycl::access::target accessTargetOrig,
            cl::sycl::access::target accessTargetDest,
            access::placeholder isPlaceholderOrig,
            access::placeholder isPlaceholderDest,
            COMPUTECPP_ENABLE_IF(
                TOrig, ((detail::can_copy_types<TOrig, TDest>::value) &&
                        (detail::is_read_mode<accessModeOrig>::value) &&
                        (detail::is_write_mode<accessModeDest>::value)))>
  void copy(
      accessor<TOrig, dims, accessModeOrig, accessTargetOrig, isPlaceholderOrig>
          originAcc,
      accessor<TDest, dims, accessModeDest, accessTargetDest, isPlaceholderDest>
          destinationAcc) {
    this->copy_in_device(originAcc, destinationAcc);
  }

  /**
    @brief Fills the data associated with the accessor using the scalar value.

           Special case of copy from host to device where the origin is a scalar
           value that will be replicated across the range of the accessor.
    @tparam TAcc Underlying type of the data associated with the accessor
    @tparam T Underlying type of the host scalar
    @tparam dims Number of dimensions of the accessor
    @tparam accessMode Access mode of the accessor
    @tparam accessTarget Access target of the accessor
    @tparam isPlaceholder Whether the accessor is a placeholder
    @tparam COMPUTECPP_ENABLE_IF The function is only valid when the access mode
            includes read access
    @param acc Accessor with the data that will be filled
    @param val Scalar used to fill the device data with
  */
  template <
      typename TAcc, typename T, int dims, cl::sycl::access::mode accessMode,
      cl::sycl::access::target accessTarget, access::placeholder isPlaceholder,
      COMPUTECPP_ENABLE_IF(TAcc, (detail::can_copy_types<T, TAcc>::value &&
                                  detail::is_write_mode<accessMode>::value))>
  void fill(accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc,
            T val) {
    static_assert(((sizeof(T) == 1) || (sizeof(T) == 2) || (sizeof(T) == 4) ||
                   (sizeof(T) == 8) || (sizeof(T) == 16) || (sizeof(T) == 32) ||
                   (sizeof(T) == 64) || (sizeof(T) == 128)),
                  "The size of the scalar type can only be one of "
                  "{1, 2, 4, 8, 16, 32, 64, 128}");
    this->fill(acc, static_cast<const void *>(&val), sizeof(T));
  }

  /**
   * @brief Updates the device data with the current host accessor
   * @param AccessorT accessor
   */
  template <typename T, int dims, cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder>
  void update_host(
      accessor<T, dims, accessMode, accessTarget, isPlaceholder> acc) {
    update_device_data(acc, nullptr, cl::sycl::access::mode::write, false);
  }

 protected:
  /**
    @brief Updates device data by copying to/from the device
    @param acc Accessor that is used to access the buffer or image
    @param hostPtr Pointer that points to data on the host
    @param accessMode Operation indicator
                      (read -> copy_from_device, write -> copy_to_device)
    @param userProvidedPtr Indicated whether the host pointer was provided by
    the user or whether to use the internal one
  */
  void update_device_data(const accessor_base &acc,
                          shared_ptr_class<void> hostPtr,
                          cl::sycl::access::mode accessMode,
                          bool userProvidedPtr);

  /**
    @brief Copies data associated with the origin accessor to the data
           associated with the destination accessor.
    @param originAcc Accessor with the data that will be copied from
    @param destinationAcc Accessor with the data that will be copied to
  */
  void copy_in_device(const accessor_base &originAcc,
                      const accessor_base &destinationAcc);

  /**
    @brief Fills the range of the accessor with value of \ref{hostScalarPtr[0]}
    @param acc Accessor with the data that will be filled
    @param patternData Host data used to fill the device data with
    @param patternSize Size of the host data
  */
  void fill(const accessor_base &acc, const void *patternData,
            const size_t patternSize);

 protected:
  /** handler.
   * Creates a handler for an specific queue.
   */
  explicit handler(const dqueue_shptr &q,
                   const dqueue_shptr &fallbackQueue = nullptr);

  /** get_context.
   * Returns the current context for the command group.
   */
  context get_context() const;

  /** execute_kernel.
   * Creates the internal structures to execute the kernel.
   * This function is explicitly instantiated on the cpp file for
   * those FunctorPtr types supported.
   *
   * @param nd_range_base The given nd range
   * @param syclKernel The SYCL device kernel
   * @param FunctorPtr  The std::function pointer to the user functor
   * @param currentCommand  The command currently being executing
   */
  void execute_kernel_single_task_ptr(
      const detail::nd_range_base &ndRange, const kernel &syclKernel,
      const detail::single_task_ptr &funcPtr,
      detail::enqueue_device_kernel_command *currentCommand);
  void execute_kernel_parallel_for_ptr(
      const detail::nd_range_base &ndRange, const kernel &syclKernel,
      const detail::parallel_for_ptr &funcPtr,
      detail::enqueue_device_kernel_command *currentCommand);
  void execute_kernel_parallel_for_id_ptr(
      const detail::nd_range_base &ndRange, const kernel &syclKernel,
      const detail::parallel_for_id_ptr &funcPtr,
      detail::enqueue_device_kernel_command *currentCommand);
  void execute_kernel_parallel_for_work_group_ptr(
      const detail::nd_range_base &ndRange, const kernel &syclKernel,
      const detail::parallel_for_work_group_ptr &funcPtr,
      detail::enqueue_device_kernel_command *currentCommand);

  /** process_functor_arguments_impl.
   * Gets the parameters from a functor and sets them as OpenCL arguments.
   * Internal implementation.
   * @param syclKernel Kernel to which the functor is associated
   * @param functorBuffer Functor buffer casted down to a binary array
   * @param SI Kernel struct iterator
   * @param SE Kernel struct iterator
   * @param OI Kernel struct iterator
   */
  void process_functor_arguments_impl(
      kernel syclKernel, detail::binary_address functorBuffer, const size_t *SI,
      const size_t *SE, const size_t *OI, const size_t *OE,
      const detail::parameter_kind *TI, const detail::parameter_kind *TE,
      const detail::parameter_class *CI, const detail::parameter_class *CE,
      const bool *UI, const bool *UE,
      detail::enqueue_device_kernel_command *currentCommand);

  /**
    @brief Internal function that registers a placeholder accessor with the
           handler
    @param acc Placeholder accessor
  */
  void require(const accessor_base &acc, dmem_shptr bufObj = nullptr);

  /**
  * @brief Creates a kernel command group
  * Internal implementation.
  * @return Pointer to the newly created command
  */
  detail::enqueue_device_kernel_command *create_kernel_command_group();

  /** get_optimal_workgroup_size.
   * Gets the optimal workgroup size for the current device and the given
   * kernel.
   * Internal implementation.
   * @param syclKernel Kernel to which we need to compute the workgroup size.
   */
  detail::index_array get_optimal_workgroup_size(const kernel &syclKernel);

  /** m_trans.
   * Internal transaction associated with the handler
   */
  dtrans_uptr m_trans;

  /** m_queue.
   * Queue to which this handler was submitted to
   */
  dqueue_shptr m_queue;

  /**
   * @brief Pointer to the fallback queue (if any)
   */
  dqueue_shptr m_fallbackQueue;

  /* m_paramVec.
   * List of parameters to add to a kernel in
   * interop mode
   */
  vector_class<add_param_func_t> m_paramVec;

  /** m_numKernels.
   * Number of kernels in the command group.
   */
  unsigned m_numKernels;
};

/*!
@brief inner loop of parallel_for_work_group, the Hierarchical API.
@deprecated Use group::parallel_for_work_item instead
*/
template <typename functorT, int dimensions>
COMPUTECPP_DEPRECATED_API(
    "free function parallel_for_work_item was deprecated in SYCL 1.2.1")
void parallel_for_work_item(group<dimensions> groupID,
                            const functorT &functor) {
  group<dimensions>(groupID).parallel_for_work_item(functor);
}

/*!
@brief inner loop of parallel_for_work_group with a logical local range, the
Hierarchical API.
@deprecated Use group::parallel_for_work_item instead
*/
template <typename functorT, int dimensions>
COMPUTECPP_DEPRECATED_API(
    "free function parallel_for_work_item was deprecated in SYCL 1.2.1")
void parallel_for_work_item(group<dimensions> groupID,
                            range<dimensions> localRange,
                            const functorT &functor) {
  group<dimensions>(groupID).parallel_for_work_item(localRange, functor);
}

namespace detail {

/**
 * @brief Helper struct for calling handler::set_args for an OpenCL kernel
 * @tparam CurrentT Type of the current parameter
 * @tparam Ts Types of subsequent parameters
 */
template <typename CurrentT, typename... Ts>
struct set_args_helper {
  /**
   * @brief Helper function for calling handler::set_args for an OpenCL kernel
   * @param cgh Command group handler
   * @param index Index of the current parameter
   * @param current Value of the current parameter
   * @param args Values of subsequent parameters
   */
  static void apply(handler &cgh, int index, CurrentT &&current,
                    Ts &&... args) {
    cgh.set_arg(index, current);
    set_args_helper<Ts...>::apply(cgh, (index + 1), std::forward<Ts>(args)...);
  }
};

/**
 * @brief Specialization of the helper struct for calling handler::set_args
 *        for an OpenCL kernel for a single parameter
 * @tparam T Type of the parameter
 */
template <typename T>
struct set_args_helper<T> {
  /**
   * @brief Helper function for calling handler::set_args with one parameter
   *        for an OpenCL kernel
   * @param cgh Command group handler
   * @param index Index of the parameter
   * @param arg Value of the parameter
   */
  static void apply(handler &cgh, int index, T &&arg) {
    cgh.set_arg(index, std::forward<T>(arg));
  }
};

}  // namespace detail

}  // namespace sycl
}  // namespace cl

#endif  // __SYCL_DEVICE_ONLY__

#ifdef __SYCL_DEVICE_ONLY__

namespace cl {
namespace sycl {

class handler {
 public:
  explicit handler(dqueue_shptr q) {}

  //////////////// Set arg mechanism
  template <typename T>
  void set_arg(int param_num, T param) {
    COMPUTECPP_CL_ERROR_CODE_MSG(
        CL_SUCCESS, detail::cpp_error_code::NOT_SUPPORTED_ERROR, nullptr,
        "Handler interoperability is not supported.");
  }
  template <typename... Ts>
  void set_args(Ts &&... args) {
    COMPUTECPP_CL_ERROR_CODE_MSG(
        CL_SUCCESS, detail::cpp_error_code::NOT_SUPPORTED_ERROR, nullptr,
        "Handler interoperability is not supported.");
  }

  /* The version of API that takes a kernel * has to be explicitly
   * deleted, otherwise it will get through the template enable_if and
   * cause a massive template error problem.
   */
  void single_task(kernel *syclKernel) = delete;
  template <int dimensions>
  void parallel_for(const nd_range<dimensions> &ndRange,
                    kernel *syclKernel) = delete;
  template <int dimensions>
  void parallel_for(const range<dimensions> &range,
                    kernel *syclKernel) = delete;
  template <int dimensions>
  void parallel_for(const range<dimensions> &range,
                    const id<dimensions> &offset, kernel *syclKernel) = delete;
  template <int dimensions>
  void parallel_work_group(const range<dimensions> &ndRange,
                           kernel *syclKernel) = delete;

  // Nothing to be done on the device side
  void single_task(kernel syclKernel) {}

  // Nothing to be done on the device side
  template <int dimensions>
  void parallel_for(const nd_range<dimensions> &ndRange, kernel syclKernel) {}

  // Nothing to be done on the device side
  template <int dimensions>
  void parallel_for(const range<dimensions> &range, kernel syclKernel) {}

  // Nothing to be done on the device side
  template <int dimensions>
  void parallel_for(const range<dimensions> &range,
                    const id<dimensions> &offset, kernel syclKernel) {}

  // Nothing to be done on the device side
  template <int dimensions>
  void parallel_work_group(const range<dimensions> &ndRange,
                           kernel syclKernel) {}

  template <typename nameT = std::nullptr_t, typename functorT>
  void single_task(const functorT &functor) {
    kernelgen_single_task<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT>
  void single_task(kernel syclKernel, const functorT &functor) {
    kernelgen_single_task<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(kernel syclKernel, const nd_range<dimensions> &ndRange,
                    const functorT &functor) {
    kernelgen_parallel_for_nd<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(const nd_range<dimensions> &ndRange,
                    const functorT &functor) {
    // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
    kernelgen_parallel_for_nd<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(kernel syclKernel, const range<dimensions> &range,
                    const functorT &functor) {
    kernelgen_parallel_for_id<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(kernel syclKernel, const range<dimensions> &globalRange,
                    const id<dimensions> &globalOffset,
                    const functorT &functor) {
    kernelgen_parallel_for_id<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(const range<dimensions> &range, const functorT &functor) {
    // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
    kernelgen_parallel_for_id<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for(const range<dimensions> &globalRange,
                    const id<dimensions> &globalOffset,
                    const functorT &functor) {
    // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
    kernelgen_parallel_for_id<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(kernel syclKernel,
                               const range<dimensions> &ndRange,
                               const functorT &functor) {
    // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
    kernelgen_parallel_for_work_group<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(const range<dimensions> &ndRange,
                               const functorT &functor) {
    // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
    kernelgen_parallel_for_work_group<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(kernel syclKernel,
                               const range<dimensions> &ndRange,
                               const range<dimensions> &localRange,
                               const functorT &functor) {
    // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
    kernelgen_parallel_for_work_group<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor, localRange);
  }

  template <typename nameT = std::nullptr_t, typename functorT, int dimensions>
  void parallel_for_work_group(const range<dimensions> &ndRange,
                               const range<dimensions> &localRange,
                               const functorT &functor) {
    // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
    kernelgen_parallel_for_work_group<
        typename detail::enable_functor<functorT, nameT>::kernel_name,
        functorT>(functor);
  }

  template <typename elemT, int kDims, access::mode kMode,
            access::target kTarget>
  void require(const accessor<elemT, kDims, kMode, kTarget,
                              access::placeholder::true_t> &acc) {
    // NOT ACTUALLY CALLED
  }

  template <typename elemT, int kDims, access::mode kMode,
            access::target kTarget>
  void require(buffer<elemT, kDims> &bufObj,
               const accessor<elemT, kDims, kMode, kTarget,
                              access::placeholder::true_t> &acc) {
    // NOT ACTUALLY CALLED
  }

  /////////////// API : Copy from/to/in device

  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<TAcc, THostPtr>::value &&
                       detail::is_read_mode<accessMode>::value))>
  void copy(accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc,
            shared_ptr_class<THostPtr> hostPtr) {
    // No work for the device compiler
  }
  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<THostPtr, TAcc>::value &&
                       detail::is_write_mode<accessMode>::value))>
  void copy(shared_ptr_class<THostPtr> hostPtr,
            accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc) {
    // No work for the device compiler
  }
  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<TAcc, THostPtr>::value &&
                       detail::is_read_mode<accessMode>::value))>
  void copy(accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc,
            THostPtr *hostPtr) {
    // No work for the device compiler
  }
  template <typename TAcc, typename THostPtr, int dims,
            cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder,
            COMPUTECPP_ENABLE_IF(
                TAcc, (detail::can_copy_types<THostPtr, TAcc>::value &&
                       detail::is_write_mode<accessMode>::value))>
  void copy(THostPtr *hostPtr,
            accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc) {
    // No work for the device compiler
  }
  template <typename TOrig, typename TDest, int dims,
            cl::sycl::access::mode accessModeOrig,
            cl::sycl::access::mode accessModeDest,
            cl::sycl::access::target accessTargetOrig,
            cl::sycl::access::target accessTargetDest,
            access::placeholder isPlaceholderOrig,
            access::placeholder isPlaceholderDest,
            COMPUTECPP_ENABLE_IF(
                TOrig, ((detail::can_copy_types<TOrig, TDest>::value) &&
                        (detail::is_read_mode<accessModeOrig>::value) &&
                        (detail::is_write_mode<accessModeDest>::value)))>
  void copy(
      accessor<TOrig, dims, accessModeOrig, accessTargetOrig, isPlaceholderOrig>
          originAcc,
      accessor<TDest, dims, accessModeDest, accessTargetDest, isPlaceholderDest>
          destinationAcc) {
    // No work for the device compiler
  }
  template <
      typename TAcc, typename T, int dims, cl::sycl::access::mode accessMode,
      cl::sycl::access::target accessTarget, access::placeholder isPlaceholder,
      COMPUTECPP_ENABLE_IF(TAcc, (detail::can_copy_types<T, TAcc>::value &&
                                  detail::is_write_mode<accessMode>::value))>
  void fill(accessor<TAcc, dims, accessMode, accessTarget, isPlaceholder> acc,
            T val) {
    // No work for the device compiler
  }

  template <typename T, int dims, cl::sycl::access::mode accessMode,
            cl::sycl::access::target accessTarget,
            access::placeholder isPlaceholder>
  void update_host(
      accessor<T, dims, accessMode, accessTarget, isPlaceholder> acc) {
    // No work for the device compiler
  }
};

template <typename functorT, int dimensions>
COMPUTECPP_DEPRECATED_API(
    "free function parallel_for_work_item was deprecated in SYCL 1.2.1")
void parallel_for_work_item(group<dimensions> groupID,
                            const functorT &functor) {
  // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
  kernelgen_parallel_for_work_item<functorT>(groupID, functor);
}

template <typename functorT, int dimensions>
COMPUTECPP_DEPRECATED_API(
    "free function parallel_for_work_item was deprecated in SYCL 1.2.1")
void parallel_for_work_item(group<dimensions> groupID,
                            range<dimensions> localRange,
                            const functorT &functor) {
  // NOT ACTUALLY CALLED ONLY HERE TO CALL THE KERNEL GEN FUNCTION
  kernelgen_parallel_for_work_item<functorT>(groupID, localRange, functor);
}

}  // namespace sycl
}  // namespace cl

#endif  // __SYCL_DEVICE_ONLY__

#endif  // RUNTIME_INCLUDE_SYCL_APIS_H_
