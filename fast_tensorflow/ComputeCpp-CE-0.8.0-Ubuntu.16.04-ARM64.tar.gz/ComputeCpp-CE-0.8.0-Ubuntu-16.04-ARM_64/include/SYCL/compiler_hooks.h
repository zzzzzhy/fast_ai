/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp


*******************************************************************************/

#ifndef RUNTIME_INCLUDE_SYCL_COMPILER_HOOKS_H_
#define RUNTIME_INCLUDE_SYCL_COMPILER_HOOKS_H_

#include "SYCL/common.h"
#include "SYCL/group_base.h"
#include "SYCL/item_base.h"
#include "SYCL/sycl_builtins.h"

/*!
  @file compiler_hooks.h
  @brief Internal file used by runtime to implement the kernel invoking APIs for
  the device.
*/
namespace cl {
namespace sycl {
/*! @cond COMPUTECPP_DEV */

#ifdef __SYCL_DEVICE_ONLY__

// Disable some warnings in case -Werror is used
// These warnings only appear in this file
COMPUTECPP_HOST_CXX_DIAGNOSTIC(push)
COMPUTECPP_HOST_CXX_DIAGNOSTIC(ignored "-Wsign-compare")

/**
 * Define the device_call functions for ComputeCpp device compiler.
 * In this case, we are defining the functions purely to be
 * the root of the kernel call-stack.
 */

/** kernelgen_single_task.
 * Kernel generation for the single task API entry.
 * @param functorT Functor containing the kernel.
 */
template <typename kernelT, typename functorT>
__attribute__((__sycl_kernel(kernelT))) __attribute__((__offload__)) void
kernelgen_single_task(functorT functor) {
  functor();
}

template <class kernelT, class functorT>
__attribute__((__sycl_kernel(kernelT))) __attribute__((__offload__)) void
kernelgen_parallel_for_nd(functorT functor) {
  detail::index_array localID(detail::get_local_id(0), detail::get_local_id(1),
                              detail::get_local_id(2));

  detail::index_array globalID(detail::get_global_id(0),
                               detail::get_global_id(1),
                               detail::get_global_id(2));

  detail::index_array groupID(detail::get_group_id(0), detail::get_group_id(1),
                              detail::get_group_id(2));

  detail::index_array localRange(detail::get_local_size(0),
                                 detail::get_local_size(1),
                                 detail::get_local_size(2));

  detail::index_array globalRange(detail::get_global_size(0),
                                  detail::get_global_size(1),
                                  detail::get_global_size(2));

  detail::index_array globalOffset(detail::get_global_offset(0),
                                   detail::get_global_offset(1),
                                   detail::get_global_offset(2));
  detail::nd_item_base ndItemID(localID, globalID, localRange, globalRange,
                                globalOffset, groupID);

  functor(ndItemID);
}

/** kernelgen_parallel_for_id.
 * Kernel generation for the parallel_for_id API entry.
 * @param functorT Functor containing the kernel.
 */
template <class kernelT, class functorT>
__attribute__((__sycl_kernel(kernelT))) __attribute__((__offload__)) void
kernelgen_parallel_for_id(functorT functor) {
  detail::index_array globalID(detail::get_global_id(0),
                               detail::get_global_id(1),
                               detail::get_global_id(2));

  detail::index_array globalRange(detail::get_global_size(0),
                                  detail::get_global_size(1),
                                  detail::get_global_size(2));
  detail::item_base itemID(globalID, globalRange);
  functor(itemID);
}

#define COMPUTECPP_SYCL_DEVFUNC __attribute__((__offload__)) inline

/*!
Check functions that are inserted by the compiler before and after local and
global stores in functions qualified with the address_space_of_locals attribute.
*/
extern "C" {
/*!
@brief Function called before local stores, returns true if the linear local id
is 0.
@return boolean specifying if the linear local id is 0.
*/
COMPUTECPP_SYCL_DEVFUNC bool __check_local_() {
  return !(detail::get_local_id(0) | detail::get_local_id(1) |
           detail::get_local_id(2));
}

/*!
@brief Function called after local stores
*/
__attribute__((noduplicate)) COMPUTECPP_SYCL_DEVFUNC void
__check_after_local_() {
  _Z7barrierj(COMPUTECPP_CLK_LOCAL_MEM_FENCE | COMPUTECPP_CLK_GLOBAL_MEM_FENCE);
}

/*!
@brief Function called before global stores, returns true if the linear global
id is 0.
@return boolean specifying if the linear global id is 0.
*/
COMPUTECPP_SYCL_DEVFUNC bool __check_global_() {
  return !(detail::get_local_id(0) | detail::get_local_id(1) |
           detail::get_local_id(2));
}

/*!
@brief Function called after global stores
*/
__attribute__((noduplicate)) COMPUTECPP_SYCL_DEVFUNC void
__check_after_global_() {
  _Z7barrierj(COMPUTECPP_CLK_LOCAL_MEM_FENCE | COMPUTECPP_CLK_GLOBAL_MEM_FENCE);
}
}

#undef COMPUTECPP_SYCL_DEVFUNC

#define COMPUTECPP_ASP_OPENCL_LOCAL 0x7FFF01

/** kernelgen_parallel_for_work_group.
 * Kernel generation for the parallel_for_work_group API entry.
 * @param functorT Functor containing the kernel.
 */
template <class kernelT, class functorT>
__attribute__((__sycl_kernel(kernelT, 2))) __attribute__((__offload__(2)))
__attribute__((address_space_of_locals(COMPUTECPP_ASP_OPENCL_LOCAL, 1))) void
kernelgen_parallel_for_work_group(functorT functor) {
  detail::index_array groupID(detail::get_group_id(0), detail::get_group_id(1),
                              detail::get_group_id(2));
  detail::index_array workGroups(detail::get_num_groups(0),
                                 detail::get_num_groups(1),
                                 detail::get_num_groups(2));
  detail::index_array globalRange(detail::get_global_size(0),
                                  detail::get_global_size(1),
                                  detail::get_global_size(2));
  detail::index_array localRange(detail::get_local_size(0),
                                 detail::get_local_size(1),
                                 detail::get_local_size(2));

  detail::group_base groupObj(groupID, workGroups, globalRange, localRange);

  functor(groupObj);
}

#undef COMPUTECPP_ASP_OPENCL_LOCAL

/** kernelgen_parallel_for_work_item.
 * Kernel generation for the parallel_for_work_item.
 * @param group groupID Group identification
 * @param functorT functor containing the code for the work-item
 */
template <typename functorT>
__attribute__((__offload__)) void kernelgen_parallel_for_work_item(
    detail::group_base groupP, functorT functor) {
  detail::index_array localID(detail::get_local_id(0), detail::get_local_id(1),
                              detail::get_local_id(2));

  detail::index_array globalID(detail::get_global_id(0),
                               detail::get_global_id(1),
                               detail::get_global_id(2));

  detail::index_array localRange(detail::get_local_size(0),
                                 detail::get_local_size(1),
                                 detail::get_local_size(2));

  detail::index_array globalRange(detail::get_global_size(0),
                                  detail::get_global_size(1),
                                  detail::get_global_size(2));

  detail::h_item_base itemID(localID, globalID, localRange, globalRange,
                             localRange);

  ::cl::sycl::detail::barrier(
      static_cast<cl_uint>(access::fence_space::global_and_local));
  functor(itemID);
  ::cl::sycl::detail::barrier(
      static_cast<cl_uint>(access::fence_space::global_and_local));
}

/** kernelgen_parallel_for_work_item.
 * Kernel generation for the parallel_for_work_item.
 * @param group groupID Group identification
 * @param localRange user provided local range
 * @param functorT functor containing the code for the work-item
 */
template <typename functorT>
__attribute__((__offload__)) void kernelgen_parallel_for_work_item(
    detail::group_base groupP, detail::index_array localRange,
    functorT functor) {
  // actual local id
  detail::index_array phyLocalID(detail::get_local_id(0),
                                 detail::get_local_id(1),
                                 detail::get_local_id(2));

  // actual local range
  detail::index_array phyLocalRange(detail::get_local_size(0),
                                    detail::get_local_size(1),
                                    detail::get_local_size(2));

  detail::index_array globalID(detail::get_global_id(0),
                               detail::get_global_id(1),
                               detail::get_global_id(2));

  detail::index_array globalRange(detail::get_global_size(0),
                                  detail::get_global_size(1),
                                  detail::get_global_size(2));

  detail::barrier(static_cast<cl_uint>(access::fence_space::global_and_local));
  for (int item_z = phyLocalID[2]; item_z < localRange[2];
       item_z += phyLocalRange[2]) {
    for (int item_y = phyLocalID[1]; item_y < localRange[1];
         item_y += phyLocalRange[1]) {
      for (int item_x = phyLocalID[0]; item_x < localRange[0];
           item_x += phyLocalRange[0]) {
        detail::index_array localID(item_x, item_y, item_z);

        detail::h_item_base itemID(localID, globalID, localRange, globalRange,
                                   phyLocalRange);
        functor(itemID);
      }
    }
  }
  ::cl::sycl::detail::barrier(
      static_cast<cl_uint>(access::fence_space::global_and_local));
}

COMPUTECPP_HOST_CXX_DIAGNOSTIC(pop)

#endif  // __SYCL_DEVICE_ONLY__
/// COMPUTECPP_DEV @endcond

}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_COMPILER_HOOKS_H_
