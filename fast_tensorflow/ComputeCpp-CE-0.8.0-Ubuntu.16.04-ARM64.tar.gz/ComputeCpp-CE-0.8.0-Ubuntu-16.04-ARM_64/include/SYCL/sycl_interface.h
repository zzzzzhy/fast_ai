/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file sycl_interface.h

  @brief This file is an unified header file which includes all required
  header files for the sycl runtime interface.
 */

#ifndef RUNTIME_INCLUDE_SYCL_INTERFACE_H_
#define RUNTIME_INCLUDE_SYCL_INTERFACE_H_

// This has to be included first
#include "SYCL/common.h"

#ifdef __SYCL_DEVICE_ONLY__
#include "SYCL/compiler_hooks.h"
#include "SYCL/serial_memop.h"
#endif

#if COMPUTECPP_OPENGL_INTEROP_AVAILABLE
#include <GL/gl.h>
#endif  // COMPUTECPP_OPENGL_INTEROP_AVAILABLE

// Disable some warnings on Linux in case -Werror is used
COMPUTECPP_HOST_CXX_DIAGNOSTIC(push)
COMPUTECPP_HOST_CXX_DIAGNOSTIC(ignored "-Wunused-parameter")

#include "SYCL/accessor.h"
#include "SYCL/accessor_args.h"
#include "SYCL/accessor_base.h"
#include "SYCL/accessor_ops.h"
#include "SYCL/allocator.h"
#include "SYCL/apis.h"
#include "SYCL/atomic.h"
#include "SYCL/atomic_device.h"
#include "SYCL/base.h"
#include "SYCL/buffer.h"
#include "SYCL/cl_types.h"
#include "SYCL/cl_vec_types.h"
#include "SYCL/codeplay/pointer_mapper.h"
#include "SYCL/context.h"
#include "SYCL/device.h"
#include "SYCL/device_info.h"
#include "SYCL/device_selector.h"
#include "SYCL/error.h"
#include "SYCL/event.h"
#include "SYCL/group.h"
#include "SYCL/group_base.h"
#include "SYCL/half_type.h"
#include "SYCL/id.h"
#include "SYCL/image.h"
#include "SYCL/index_array.h"
#include "SYCL/index_array_operators.h"
#include "SYCL/info.h"
#include "SYCL/item.h"
#include "SYCL/item_base.h"
#include "SYCL/kernel.h"
#include "SYCL/multi_pointer.h"
#include "SYCL/nd_range_base.h"
#include "SYCL/platform.h"
#include "SYCL/private_memory.h"
#include "SYCL/program.h"
#include "SYCL/property.h"
#include "SYCL/queue.h"
#include "SYCL/range.h"
#include "SYCL/sampler.h"
#include "SYCL/storage_mem.h"
#include "SYCL/stream.h"
#include "SYCL/task.h"
#include "SYCL/vec.h"
#include "SYCL/vec_common.h"
#include "SYCL/vec_load_store.h"
#include "SYCL/vec_macros.h"
#include "SYCL/vec_swizzles.h"
#include "SYCL/vec_swizzles_impl.h"

COMPUTECPP_HOST_CXX_DIAGNOSTIC(pop)

// This has to be included last
#include "SYCL/postdefines.h"

#endif  // RUNTIME_INCLUDE_SYCL_INTERFACE_H_
