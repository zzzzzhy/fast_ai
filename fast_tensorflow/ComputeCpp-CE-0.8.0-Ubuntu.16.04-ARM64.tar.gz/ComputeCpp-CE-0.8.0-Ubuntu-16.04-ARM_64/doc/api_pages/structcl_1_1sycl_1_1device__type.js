var structcl_1_1sycl_1_1device__type =
[
    [ "ptr_t", "structcl_1_1sycl_1_1device__type.html#a1d0073b6309be1bc6199b4bfdb187ad4", null ],
    [ "underlying_t", "structcl_1_1sycl_1_1device__type.html#a91121534ee36f7a8ffd8ad329a8a92e6", null ]
];