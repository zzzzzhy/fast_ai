var classcl_1_1sycl_1_1opencl__selector =
[
    [ "opencl_selector", "classcl_1_1sycl_1_1opencl__selector.html#a93e474f1bb926dfff133c089db022b1f", null ],
    [ "~opencl_selector", "classcl_1_1sycl_1_1opencl__selector.html#af10a66fe5b4c2d32298e109be3386e06", null ],
    [ "operator()", "classcl_1_1sycl_1_1opencl__selector.html#a9f55b6f281200fb4e35c64c0c777eb26", null ]
];