var platform_8h =
[
    [ "platform", "classcl_1_1sycl_1_1platform.html", "classcl_1_1sycl_1_1platform" ],
    [ "info_convert< cl_platform_id *, platform >", "structcl_1_1sycl_1_1info__convert_3_01cl__platform__id_01_5_00_01platform_01_4.html", null ],
    [ "hash< cl::sycl::platform >", "structstd_1_1hash_3_01cl_1_1sycl_1_1platform_01_4.html", "structstd_1_1hash_3_01cl_1_1sycl_1_1platform_01_4" ],
    [ "platform", "platform_8h.html#a3ea7e38ccbc7de5270c4f69bbae20463", [
      [ "profile", "platform_8h.html#a3ea7e38ccbc7de5270c4f69bbae20463a7d97481b1fe66f4b51db90da7e794d9f", null ],
      [ "version", "platform_8h.html#a3ea7e38ccbc7de5270c4f69bbae20463a2af72f100c356273d46284f6fd1dfc08", null ],
      [ "name", "platform_8h.html#a3ea7e38ccbc7de5270c4f69bbae20463ab068931cc450442b63f5b3d276ea4297", null ],
      [ "vendor", "platform_8h.html#a3ea7e38ccbc7de5270c4f69bbae20463a7c3613dba5171cb6027c67835dd3b9d4", null ],
      [ "extensions", "platform_8h.html#a3ea7e38ccbc7de5270c4f69bbae20463a2ac737d240fc746cef37129b7569f08e", null ]
    ] ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "platform_8h.html#a4bb213e6c13694944fb744e69fd487ef", null ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "platform_8h.html#a393f2dca504fea01b81e35886a816510", null ]
];