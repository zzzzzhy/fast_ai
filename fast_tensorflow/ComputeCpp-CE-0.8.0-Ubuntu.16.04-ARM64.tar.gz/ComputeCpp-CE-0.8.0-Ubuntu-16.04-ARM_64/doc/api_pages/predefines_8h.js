var predefines_8h =
[
    [ "CL_SYCL_LANGUAGE_VERSION", "predefines_8h.html#a8e112aad8caa16ff75a8218e952d347c", null ],
    [ "COMPUTECPP_DEPRECATED_API", "predefines_8h.html#ab63ff464787dd728d80af8d7def7e2c4", null ],
    [ "COMPUTECPP_OPENGL_INTEROP_AVAILABLE", "predefines_8h.html#a9649973c90629586058e143234450237", null ]
];