var classcl_1_1sycl_1_1kernel =
[
    [ "kernel", "classcl_1_1sycl_1_1kernel.html#a47dfa655e243fdaebb5f0197ac002c64", null ],
    [ "kernel", "classcl_1_1sycl_1_1kernel.html#a1b5dd4df645aa27b90c1de1d91ec32f7", null ],
    [ "~kernel", "classcl_1_1sycl_1_1kernel.html#afb6f3538ae969ff6078107fe002cfe44", null ],
    [ "kernel", "classcl_1_1sycl_1_1kernel.html#aa7cb6dcd9c59301285c8ff3a5e85fdb7", null ],
    [ "kernel", "classcl_1_1sycl_1_1kernel.html#ad9c2efd107a71f403f6c4afe7c2cfa00", null ],
    [ "get", "classcl_1_1sycl_1_1kernel.html#a8864ef3db82bfd13343d6c8d344a1fda", null ],
    [ "get_context", "classcl_1_1sycl_1_1kernel.html#a59bd2e0a972b534d65e9dcd835d61922", null ],
    [ "get_info", "classcl_1_1sycl_1_1kernel.html#a885824837d3b386833253d25c4ca1f5d", null ],
    [ "get_no_retain", "classcl_1_1sycl_1_1kernel.html#a398432ee6ddedc3a481a0aab18e75c05", null ],
    [ "get_program", "classcl_1_1sycl_1_1kernel.html#a83d5c90c2181e6fed2578ea1484c8f01", null ],
    [ "get_work_group_info", "classcl_1_1sycl_1_1kernel.html#a97f1e1a620e9a2029265d7b829dd5576", null ],
    [ "is_host", "classcl_1_1sycl_1_1kernel.html#a31967cb7e61dac61a2061f21784fb6a1", null ],
    [ "operator=", "classcl_1_1sycl_1_1kernel.html#a46b343a46d1d81bacfcc0e2a223d0afc", null ],
    [ "operator=", "classcl_1_1sycl_1_1kernel.html#a654b20f03813988540d1dac7f0fc0c14", null ],
    [ "handler", "classcl_1_1sycl_1_1kernel.html#a72db39b889f34257a4c691d6acd383ab", null ],
    [ "operator!=", "classcl_1_1sycl_1_1kernel.html#a60faabe3960320f03dc8ef7fe764a3e5", null ],
    [ "operator==", "classcl_1_1sycl_1_1kernel.html#a0b3a3fc44daca79e6079f17fa1d6a2dd", null ]
];