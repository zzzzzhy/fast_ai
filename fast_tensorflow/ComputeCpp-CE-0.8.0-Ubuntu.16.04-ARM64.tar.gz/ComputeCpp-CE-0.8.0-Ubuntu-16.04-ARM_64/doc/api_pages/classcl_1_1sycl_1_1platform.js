var classcl_1_1sycl_1_1platform =
[
    [ "platform", "classcl_1_1sycl_1_1platform.html#ac766c25f9104682dd44f2bfce9ee1e1b", null ],
    [ "platform", "classcl_1_1sycl_1_1platform.html#aa1f65ac290f16f50f8c840373a26a767", null ],
    [ "platform", "classcl_1_1sycl_1_1platform.html#a10c7780bdb90b32e423f8e8aea83d326", null ],
    [ "platform", "classcl_1_1sycl_1_1platform.html#a93dbb1985231f76677f9b9d5069dfba1", null ],
    [ "~platform", "classcl_1_1sycl_1_1platform.html#a36e567129426523f06094852b6b44351", null ],
    [ "get", "classcl_1_1sycl_1_1platform.html#a4e04c4e7676e4b89736240950b8600e8", null ],
    [ "get_devices", "classcl_1_1sycl_1_1platform.html#ae2ed8f5969e9e7f3c120a4cb57488f66", null ],
    [ "get_impl", "classcl_1_1sycl_1_1platform.html#a4b7e2e67f81744a284c30f3baf37353d", null ],
    [ "get_info", "classcl_1_1sycl_1_1platform.html#ab160b867bcac0e1cd0b8b4c79d5a2516", null ],
    [ "has_extension", "classcl_1_1sycl_1_1platform.html#a72f83879bad214c84079687f39506954", null ],
    [ "is_host", "classcl_1_1sycl_1_1platform.html#acacdc85cb00467d36fa3d1724074e6f6", null ],
    [ "operator=", "classcl_1_1sycl_1_1platform.html#a3795fd2a39195529ffc03e43e03cef83", null ],
    [ "operator!=", "classcl_1_1sycl_1_1platform.html#ae29861d181b7492ca0b2c876470173a5", null ],
    [ "operator==", "classcl_1_1sycl_1_1platform.html#ad76cf3c945f017adc15d865d5e6fed44", null ],
    [ "m_impl", "classcl_1_1sycl_1_1platform.html#a8ddd9c0644c6d106a2e50697305bfcf8", null ]
];