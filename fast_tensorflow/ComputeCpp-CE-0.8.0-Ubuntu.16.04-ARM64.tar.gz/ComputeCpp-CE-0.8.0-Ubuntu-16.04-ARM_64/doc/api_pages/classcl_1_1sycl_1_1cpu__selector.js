var classcl_1_1sycl_1_1cpu__selector =
[
    [ "cpu_selector", "classcl_1_1sycl_1_1cpu__selector.html#ab34c977470a2a34149d4c688675cfd0b", null ],
    [ "~cpu_selector", "classcl_1_1sycl_1_1cpu__selector.html#a501c88a79dbb509e6ff8d2133d45adcb", null ],
    [ "operator()", "classcl_1_1sycl_1_1cpu__selector.html#a2539782ff02d2080126e5c88db5fb640", null ]
];