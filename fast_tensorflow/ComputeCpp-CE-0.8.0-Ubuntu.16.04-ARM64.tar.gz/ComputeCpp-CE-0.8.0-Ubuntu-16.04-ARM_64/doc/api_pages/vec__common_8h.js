var vec__common_8h =
[
    [ "elem", "structcl_1_1sycl_1_1elem.html", null ],
    [ "vec", "classcl_1_1sycl_1_1vec.html", null ],
    [ "swizzled_vec", "classcl_1_1sycl_1_1swizzled__vec.html", null ],
    [ "rounding_mode", "vec__common_8h.html#a16ab217f4d07c904f763adf0a270d1c0", [
      [ "automatic", "vec__common_8h.html#a16ab217f4d07c904f763adf0a270d1c0a2bd9c0ed00116be1258e0cc66617d7c8", null ],
      [ "rte", "vec__common_8h.html#a16ab217f4d07c904f763adf0a270d1c0ae3fd2afa75b6e2e40021c7054361fbf4", null ],
      [ "rtz", "vec__common_8h.html#a16ab217f4d07c904f763adf0a270d1c0acf5c5662f49f76f9bbd776d77935b422", null ],
      [ "rtp", "vec__common_8h.html#a16ab217f4d07c904f763adf0a270d1c0ac766e112de79c244fdaed0ed34ca5e12", null ],
      [ "rtn", "vec__common_8h.html#a16ab217f4d07c904f763adf0a270d1c0aa1ddc56bf1413a90046522963aaf37ab", null ]
    ] ]
];