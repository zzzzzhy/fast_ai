var namespacecl_1_1sycl_1_1property =
[
    [ "buffer", "namespacecl_1_1sycl_1_1property_1_1buffer.html", "namespacecl_1_1sycl_1_1property_1_1buffer" ],
    [ "image", "namespacecl_1_1sycl_1_1property_1_1image.html", null ],
    [ "queue", "namespacecl_1_1sycl_1_1property_1_1queue.html", "namespacecl_1_1sycl_1_1property_1_1queue" ]
];