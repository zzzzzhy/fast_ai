var structcl_1_1sycl_1_1device__stream__metadata =
[
    [ "field_type", "structcl_1_1sycl_1_1device__stream__metadata.html#aa2f496a4c4dc0331ede66271dd3113d8", null ],
    [ "operator==", "structcl_1_1sycl_1_1device__stream__metadata.html#aaf185ed91ac8a342f58945b3af6808c2", null ],
    [ "m_bufferSize", "structcl_1_1sycl_1_1device__stream__metadata.html#aacee246787cd7db81103872c770af987", null ],
    [ "m_currentIndex", "structcl_1_1sycl_1_1device__stream__metadata.html#a194840ea543ee24e36179a06d24b883f", null ],
    [ "m_maxStatementSize", "structcl_1_1sycl_1_1device__stream__metadata.html#a917389dbb4b95aa96be1e834ffbec857", null ],
    [ "m_streamMode", "structcl_1_1sycl_1_1device__stream__metadata.html#ae10590b26812659ec970aab6960763e4", null ]
];