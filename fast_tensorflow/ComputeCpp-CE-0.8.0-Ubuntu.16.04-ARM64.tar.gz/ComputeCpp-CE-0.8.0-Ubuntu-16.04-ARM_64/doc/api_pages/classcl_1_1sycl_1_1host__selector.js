var classcl_1_1sycl_1_1host__selector =
[
    [ "host_selector", "classcl_1_1sycl_1_1host__selector.html#af98a1cd45a10a85794c2fc877f818c76", null ],
    [ "~host_selector", "classcl_1_1sycl_1_1host__selector.html#a8c214995df0369a040e65a04d623e5b2", null ],
    [ "operator()", "classcl_1_1sycl_1_1host__selector.html#a6252636a92e33bccd5573ea08f4e9fff", null ]
];