var classcl_1_1sycl_1_1property__list =
[
    [ "property_list", "classcl_1_1sycl_1_1property__list.html#ae75fab796ceac156e45aead37e73cc65", null ]
];