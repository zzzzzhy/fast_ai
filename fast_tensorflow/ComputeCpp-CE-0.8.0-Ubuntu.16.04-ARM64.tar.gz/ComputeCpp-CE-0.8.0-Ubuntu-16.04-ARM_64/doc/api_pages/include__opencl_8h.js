var include__opencl_8h =
[
    [ "CL_USE_DEPRECATED_OPENCL_1_2_APIS", "include__opencl_8h.html#a16605039b395344c0b68b435e197b8bd", null ]
];