var structcl_1_1sycl_1_1stream__vec_3_012_00_01true_00_01element_t_00_01k_dimensions_01_4 =
[
    [ "operator()", "structcl_1_1sycl_1_1stream__vec_3_012_00_01true_00_01element_t_00_01k_dimensions_01_4.html#aba8a0889809b628a18186a51562a109a", null ]
];