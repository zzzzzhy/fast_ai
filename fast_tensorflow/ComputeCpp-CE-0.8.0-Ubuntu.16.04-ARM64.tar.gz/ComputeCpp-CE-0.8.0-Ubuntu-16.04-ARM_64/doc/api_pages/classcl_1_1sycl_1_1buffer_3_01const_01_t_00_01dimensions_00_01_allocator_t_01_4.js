var classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4 =
[
    [ "allocator_type", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a831a1547ed62537c5686945aa29fd7de", null ],
    [ "const_reference", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#ae4fdbcef0a612aba5e69da53323f60da", null ],
    [ "reference", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#ad1a45764235ea9d06cad8e029c36bfa3", null ],
    [ "value_type", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aa529fdd56b9e651dc9137712c049d928", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a7cd158516227ca3184e91305567b9b7a", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aa110d2600a53a350f92a6abeded7b338", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aabec146fb96ea730b8aca227543c299f", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aad0788351c090f0aa9138b78a4120171", null ],
    [ "~buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a5a95b04d536aa24fd7eccd434ce113db", null ],
    [ "buffer", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a72ed1dee54a74e220e484fab83d97cbe", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a60c79202cb6faad85ac31c53ccd991ef", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#ae436b6c1b3cf7638174560c89ce45d94", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a9054a2ded5faae13464fc8c45cc65e50", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a8263b83c25c50f30d29d07dd956eb3ed", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a2de5117c73a29f54bc4fd3b1b42c0b59", null ],
    [ "get_access", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#aa241fa0c1d77d13e1b02914281bb8396", null ],
    [ "get_allocator", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a948a6775977f78a265004054cc4e29c5", null ],
    [ "get_property", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a2f1a96bdf71099f6c5a9f4a5191c7ace", null ],
    [ "has_property", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a962876605d08ef83aa38a453486c574e", null ],
    [ "reinterpret", "classcl_1_1sycl_1_1buffer_3_01const_01_t_00_01dimensions_00_01_allocator_t_01_4.html#a778164e67c5e95e2593f75e6661f47a5", null ]
];