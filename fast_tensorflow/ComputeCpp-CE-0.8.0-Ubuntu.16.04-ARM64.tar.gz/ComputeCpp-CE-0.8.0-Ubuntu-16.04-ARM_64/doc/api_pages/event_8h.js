var event_8h =
[
    [ "event", "classcl_1_1sycl_1_1event.html", "classcl_1_1sycl_1_1event" ],
    [ "hash< cl::sycl::event >", "structstd_1_1hash_3_01cl_1_1sycl_1_1event_01_4.html", "structstd_1_1hash_3_01cl_1_1sycl_1_1event_01_4" ],
    [ "event", "event_8h.html#ad6dde1d8cdb42ae488540a7c276e4c56", [
      [ "command_execution_status", "event_8h.html#ad6dde1d8cdb42ae488540a7c276e4c56a3d3e95b5ca362889794d2881a835b9d4", null ],
      [ "reference_count", "event_8h.html#ad6dde1d8cdb42ae488540a7c276e4c56a40d852658166dc8a786c23023cb20f92", null ]
    ] ],
    [ "event_command_status", "event_8h.html#a475d78cf58a02b3f1abb3b1dcd144c63", [
      [ "submitted", "event_8h.html#a475d78cf58a02b3f1abb3b1dcd144c63a410d98939d4116adb562b97046d2a3eb", null ],
      [ "running", "event_8h.html#a475d78cf58a02b3f1abb3b1dcd144c63a75101dcdfc88455bcafc9e53e0b06689", null ],
      [ "complete", "event_8h.html#a475d78cf58a02b3f1abb3b1dcd144c63ad9a22d7a8178d5b42a8750123cbfe5b1", null ]
    ] ],
    [ "event_profiling", "event_8h.html#a982c34d609e64bcf30c733257890f157", [
      [ "command_submit", "event_8h.html#a982c34d609e64bcf30c733257890f157a1c2215f8145b8a68dcb5b72abb77c05d", null ],
      [ "command_start", "event_8h.html#a982c34d609e64bcf30c733257890f157a86443f0d367ba2434ee11958c89f85e9", null ],
      [ "command_end", "event_8h.html#a982c34d609e64bcf30c733257890f157adfac728d996ea99618fb8a5dfb2e48d4", null ]
    ] ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "event_8h.html#a4af8b99a29c2be96087a1475971c0de8", null ]
];