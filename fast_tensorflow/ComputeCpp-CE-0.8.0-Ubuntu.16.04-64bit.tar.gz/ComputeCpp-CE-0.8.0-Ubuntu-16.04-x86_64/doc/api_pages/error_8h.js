var error_8h =
[
    [ "exception", "classcl_1_1sycl_1_1exception.html", "classcl_1_1sycl_1_1exception" ],
    [ "exception_list", "classcl_1_1sycl_1_1exception__list.html", "classcl_1_1sycl_1_1exception__list" ],
    [ "accessor_error", "error_8h.html#a26b3883587efc3f67e30052657553052", null ],
    [ "async_handler", "error_8h.html#ad5040b06655698bb2fe2f6714ef975e7", null ],
    [ "compile_program_error", "error_8h.html#a630820affba2e000ecfa74143f27bf77", null ],
    [ "device_error", "error_8h.html#a8c1a7e136e4dd2dc75aa0b4deb7a639c", null ],
    [ "event_error", "error_8h.html#a6d226442bd39c4eda8b2dd166f028f1d", null ],
    [ "exception_ptr_class", "error_8h.html#a2142f5990bff9e140a51aac753244d37", null ],
    [ "feature_not_supported", "error_8h.html#a505adf6769c0d75bd18c054ebceb6c60", null ],
    [ "invalid_object_error", "error_8h.html#acdd32cfd630d83e73695b5c12bf71757", null ],
    [ "invalid_parameter_error", "error_8h.html#ac86e56ff8d6d6420561c14dfeb0c20b9", null ],
    [ "kernel_error", "error_8h.html#aa3dc51090f9abddcee33d5b8878f8db0", null ],
    [ "link_program_error", "error_8h.html#a700bedb7cc42bf0595dd5cdfc9e3f3b5", null ],
    [ "memory_allocation_error", "error_8h.html#afb4ccf955e2669184ea80c7f21641adf", null ],
    [ "nd_range_error", "error_8h.html#a862b2817a4338f7d1ef1b7112184e92c", null ],
    [ "platform_error", "error_8h.html#ac04478db1f220902a963283efe4c9bad", null ],
    [ "profiling_error", "error_8h.html#a04b3003136fde62bd46982a4a4a9f3c8", null ],
    [ "runtime_error", "error_8h.html#a37dd07a558854fffbd9d10a8c492b86b", null ]
];