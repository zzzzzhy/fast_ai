var device_8h =
[
    [ "device", "classcl_1_1sycl_1_1device.html", "classcl_1_1sycl_1_1device" ],
    [ "info_convert< cl_device_id *, device >", "structcl_1_1sycl_1_1info__convert_3_01cl__device__id_01_5_00_01device_01_4.html", null ],
    [ "hash< cl::sycl::device >", "structstd_1_1hash_3_01cl_1_1sycl_1_1device_01_4.html", "structstd_1_1hash_3_01cl_1_1sycl_1_1device_01_4" ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "device_8h.html#a93c51d851e776da6ded1e6ccb6f96412", null ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "device_8h.html#a0b0cd91878c00d22a76ce854f910e231", null ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "device_8h.html#a99a9041c88f301a0a09465299e7a9575", null ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "device_8h.html#aa45034b00fab265ff2abe8c7b07004cc", null ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "device_8h.html#adcf84ab296dcee070f0ed784bd394429", null ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "device_8h.html#aa2830508d08a6bae96c51d0aaa2c030d", null ],
    [ "COMPUTECPP_GET_INFO_SPECIALIZATION_DECL", "device_8h.html#a42366f0190799080b8a7d6c341c4ead3", null ],
    [ "device::create_sub_devices< info::partition_property::partition_by_affinity_domain >", "device_8h.html#af31f5963c4a912782aca2204d9c1d673", null ],
    [ "device::create_sub_devices< info::partition_property::partition_by_counts >", "device_8h.html#adf6336ef8c785b267fbc1a7d1f0e97e6", null ],
    [ "device::create_sub_devices< info::partition_property::partition_equally >", "device_8h.html#a61b11b31bf90cc328f617b030b8ce334", null ]
];