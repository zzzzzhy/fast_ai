var classcl_1_1sycl_1_1item =
[
    [ "item", "classcl_1_1sycl_1_1item.html#a66500bc79b71558b1206cd485046c346", null ],
    [ "item", "classcl_1_1sycl_1_1item.html#ac200b56528ae7adbf69ec04da8a765ff", null ],
    [ "item", "classcl_1_1sycl_1_1item.html#a9e25d659efb8596dc87812dad2d26bd4", null ],
    [ "get_id", "classcl_1_1sycl_1_1item.html#a16cbbf7ad6928fad84d7016ca4f5c499", null ],
    [ "get_id", "classcl_1_1sycl_1_1item.html#aa82ed18a691ddab02df769f5b3940d35", null ],
    [ "get_offset", "classcl_1_1sycl_1_1item.html#aa74c3505c2a3fc7d0fdfbdf6b6250873", null ],
    [ "get_range", "classcl_1_1sycl_1_1item.html#a8f59eece8ea9cf4bea328daf2b80b20c", null ],
    [ "operator detail::enable_if_t< has_no_offset< sfinae >", "classcl_1_1sycl_1_1item.html#a51e4fc8bd0179065ad534fc243ffb691", null ],
    [ "operator id< dimensions >", "classcl_1_1sycl_1_1item.html#a789a99d934ad6d6c49dfaadc813a37b8", null ],
    [ "operator!=", "classcl_1_1sycl_1_1item.html#ae7dc4aebf4a8cd0392c39035f7fad90e", null ],
    [ "operator==", "classcl_1_1sycl_1_1item.html#adb64dd38b4e2e8b864093fe4ee265cf0", null ]
];