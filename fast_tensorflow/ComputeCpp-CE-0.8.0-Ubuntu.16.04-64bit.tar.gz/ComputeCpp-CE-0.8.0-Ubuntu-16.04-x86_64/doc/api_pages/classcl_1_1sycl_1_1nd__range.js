var classcl_1_1sycl_1_1nd__range =
[
    [ "nd_range", "classcl_1_1sycl_1_1nd__range.html#a79ee30bf7879518ed4de381256c29fa3", null ],
    [ "nd_range", "classcl_1_1sycl_1_1nd__range.html#a92b969ce9f165c180b796c7423da02d1", null ],
    [ "get_global", "classcl_1_1sycl_1_1nd__range.html#aaf1172ea8b4e6677ed7b8da0776df167", null ],
    [ "get_group", "classcl_1_1sycl_1_1nd__range.html#a6013c8a258ea0f21ed3d7112648220f1", null ],
    [ "get_local", "classcl_1_1sycl_1_1nd__range.html#a62283139c5f0dff5c3cad96457e715d0", null ],
    [ "get_offset", "classcl_1_1sycl_1_1nd__range.html#a984fcb47fd7d6cd6d127ed6e599ad381", null ],
    [ "operator!=", "classcl_1_1sycl_1_1nd__range.html#a5b8f288e2c4aacd6d1ccd418ea1cf60f", null ],
    [ "operator==", "classcl_1_1sycl_1_1nd__range.html#a36de55c8b7a461894dfac52db9473bb0", null ]
];