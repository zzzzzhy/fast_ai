var classcl_1_1sycl_1_1range =
[
    [ "nd_range", "classcl_1_1sycl_1_1range.html#a2d5dd52b37f259dc8748506bde25b0d7", null ]
];