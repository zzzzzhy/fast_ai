var accessor_8h =
[
    [ "accessor", "classcl_1_1sycl_1_1accessor.html", "classcl_1_1sycl_1_1accessor" ],
    [ "accessor< elemT, kDims, kMode, kTarget, access::placeholder::true_t >", "classcl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01k_target_00_01access_1_1placeholder_1_1true__t_01_4.html", "classcl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01k_target_00_01access_1_1placeholder_1_1true__t_01_4" ],
    [ "hash< cl::sycl::accessor< elemT, kDims, kMode, kTarget > >", "structstd_1_1hash_3_01cl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01k_target_01_4_01_4.html", "structstd_1_1hash_3_01cl_1_1sycl_1_1accessor_3_01elem_t_00_01k_dims_00_01k_mode_00_01k_target_01_4_01_4" ],
    [ "COMPUTECPP_CONVERT_ATTR", "accessor_8h.html#a5f1b34b20f03e4d5837e2fcae628b6ee", null ],
    [ "COMPUTECPP_CONVERT_ATTR_PLACEHOLDER", "accessor_8h.html#a0f682d1b4ed6acccbf28315f1ca9ef2c", null ]
];