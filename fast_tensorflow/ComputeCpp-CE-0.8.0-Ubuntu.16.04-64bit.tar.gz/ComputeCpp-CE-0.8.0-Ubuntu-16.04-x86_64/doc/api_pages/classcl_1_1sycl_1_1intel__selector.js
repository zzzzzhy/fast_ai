var classcl_1_1sycl_1_1intel__selector =
[
    [ "intel_selector", "classcl_1_1sycl_1_1intel__selector.html#adc7a3d6f840f7c2bbe6412136f7ca5bd", null ],
    [ "~intel_selector", "classcl_1_1sycl_1_1intel__selector.html#a4acf44325b6524fdaaa892ac607bff33", null ],
    [ "operator()", "classcl_1_1sycl_1_1intel__selector.html#a66e949eb5f2e626673b7a0a1770b71a3", null ]
];