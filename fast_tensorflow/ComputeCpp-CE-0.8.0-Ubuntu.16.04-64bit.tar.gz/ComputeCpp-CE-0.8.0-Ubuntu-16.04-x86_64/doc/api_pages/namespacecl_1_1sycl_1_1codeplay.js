var namespacecl_1_1sycl_1_1codeplay =
[
    [ "host_handler", "classcl_1_1sycl_1_1codeplay_1_1host__handler.html", "classcl_1_1sycl_1_1codeplay_1_1host__handler" ]
];