var apis_8h =
[
    [ "handler", "classcl_1_1sycl_1_1handler.html", "classcl_1_1sycl_1_1handler" ],
    [ "COMPUTECPP_DEPRECATED_API", "apis_8h.html#a5d8bfd099fca6f3e05a408ccbd00b095", null ],
    [ "functor", "apis_8h.html#afd8687e935d3df6c3fdbbc249e467d0d", null ],
    [ "localRange", "apis_8h.html#a17e2c535e99ddcd61202a5366c835281", null ]
];