var cl__types_8h =
[
    [ "cl_bool", "cl__types_8h.html#a751286c4248f8314a8a6df67b66e0f93", null ],
    [ "cl_char", "cl__types_8h.html#a502e6b497a72668fa8177dee69bbdeb0", null ],
    [ "cl_double", "cl__types_8h.html#a79d52b28c583576e7e44ae829f64dd47", null ],
    [ "cl_float", "cl__types_8h.html#aff51d052cd64466fa8e7a78e28f59b79", null ],
    [ "cl_half", "cl__types_8h.html#a70685659e11e99216f9f7b2a8ad4d49d", null ],
    [ "cl_int", "cl__types_8h.html#a5a11da54f007ebbfe5a6b5d39c50ab96", null ],
    [ "cl_long", "cl__types_8h.html#a56965a90edc2f95b2e6b4f7012038c10", null ],
    [ "cl_short", "cl__types_8h.html#a4796b852c6ee870789be89c6a8dde688", null ],
    [ "cl_uchar", "cl__types_8h.html#a5d0bbe62fd8b28e51c0d99a51b6c0699", null ],
    [ "cl_uint", "cl__types_8h.html#aa21320f2a3be91c473a5905031fe8894", null ],
    [ "cl_ulong", "cl__types_8h.html#a1213a0bc62bd94f488f82b52891fcd06", null ],
    [ "cl_ushort", "cl__types_8h.html#a7dc59a8452fdc4ec156c4995799358dd", null ]
];