var classcl_1_1sycl_1_1private__memory =
[
    [ "private_memory", "classcl_1_1sycl_1_1private__memory.html#abb284def672428f41fead343b8ed5b22", null ],
    [ "COMPUTECPP_DEPRECATED_API", "classcl_1_1sycl_1_1private__memory.html#a1014e729a572866179ed26d5a5ee6a99", null ],
    [ "operator()", "classcl_1_1sycl_1_1private__memory.html#afc026307ba6689aba3bd4d6bfa8d0a54", null ]
];