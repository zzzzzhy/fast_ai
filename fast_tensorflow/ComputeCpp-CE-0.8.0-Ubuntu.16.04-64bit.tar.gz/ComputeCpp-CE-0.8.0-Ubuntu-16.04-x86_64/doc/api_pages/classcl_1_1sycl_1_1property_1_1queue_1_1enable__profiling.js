var classcl_1_1sycl_1_1property_1_1queue_1_1enable__profiling =
[
    [ "enable_profiling", "classcl_1_1sycl_1_1property_1_1queue_1_1enable__profiling.html#a90bc56856eef69f49c14c29ef51b2846", null ]
];