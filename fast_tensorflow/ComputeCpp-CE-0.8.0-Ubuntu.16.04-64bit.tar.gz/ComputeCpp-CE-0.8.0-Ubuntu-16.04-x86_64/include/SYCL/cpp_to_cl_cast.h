/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/
#ifndef RUNTIME_INCLUDE_SYCL_CPP_TO_CL_CAST_H_
#define RUNTIME_INCLUDE_SYCL_CPP_TO_CL_CAST_H_

#include "SYCL/half_type.h"
#include "SYCL/type_traits.h"
#include "SYCL/vec.h"
#include "computecpp/gsl/gsl"

namespace cl {
namespace sycl {
namespace detail {
template <typename T, typename U>
constexpr U cpp_to_cl_cast(T&& t) noexcept = delete;

/**
 * @brief Unary type function with a return type determined by whether or not
 *        the input is a signed type or not.
 *
 * @tparam T1 input type
 * @tparam T2 returned type if T1 is a signed type
 * @tparam T3 returned type if T1 is not a signed type
 */
template <typename T1, typename T2, typename T3>
using deduce_signedness_t =
    typename std::conditional<std::is_signed<T1>::value, T2, T3>::type;

/**
 * @brief Deduces the correct OpenCL integral type from a C++ integral type.
 *        cl_char if T is signed char, or if T is char on an implementation
 * where std::is_signed<char>::value == true;
 *        cl_uchar if T is unsigned char, or if T is char on an
 * implementation where std::is_signed<char>::value == false;
 *        cl_short if T is a signed 16-bit integer;
 *        cl_ushort if T is an unsigned 16-bit integer;
 *        cl_int if T is a signed 32-bit integer;
 *        cl_uint if T is an unsigned 32-bit integer;
 *        cl_long if T is a signed 64-bit integer
 *        cl_ulong if T is an unsigned 64-bit integer
 * @tparam T A C++ integral type.
 */
template <typename T>
using deduce_integral_t = enable_if_t<
    std::is_integral<T>::value && sizeof(T) <= 8,
    conditional_t<
        sizeof(T) == 1,
        deduce_signedness_t<T, cl::sycl::cl_char, cl::sycl::cl_uchar>,
        conditional_t<sizeof(T) == 2, deduce_signedness_t<T, cl::sycl::cl_short,
                                                          cl::sycl::cl_ushort>,
                      conditional_t<sizeof(T) == 4,
                                    deduce_signedness_t<T, cl::sycl::cl_int,
                                                        cl::sycl::cl_uint>,
                                    deduce_signedness_t<T, cl::sycl::cl_long,
                                                        cl::sycl::cl_ulong>>>>>;

/**
 * @brief  Converts a C++ fundamental type to the equivalent OpenCL type.
 * @tparam T A C++ integral type.
 * @tparam U cl_char if T is signed char, or if T is char on an implementation
 * where std::is_signed<char>::value == true;
 *           cl_uchar if T is unsigned char, or if T is char on an
 * implementation where std::is_signed<char>::value == false;
 *           cl_short if T is a signed 16-bit integer;
 *           cl_ushort if T is an unsigned 16-bit integer;
 *           cl_int if T is a signed 32-bit integer;
 *           cl_uint if T is an unsigned 32-bit integer;
 *           cl_long if T is a signed 64-bit integer
 *           cl_ulong if T is an unsigned 64-bit integer
 * @param t The object to be converted.
 * @return An object of type U with an equivalent value to t.
 */
template <typename T, typename U = deduce_integral_t<T>>
constexpr auto cpp_to_cl_cast(const T t) noexcept
    -> requires_is_same_t<U, deduce_integral_t<T>> {
  return static_cast<U>(t);
}

/**
 * @brief  Converts a cl::sycl::vec<T, N> type to the equivalent OpenCL type.
 * @tparam T A C++ integral type.
 * @tparam N The dimension of the vector.
 * @tparam U vec<cl_char, N> if T is signed char, or if T is char on an
 * implementation where std::is_signed<char>::value == true;
 *           vec<cl_uchar, N> if T is unsigned char, or if T is char on an
 * implementation where std::is_signed<char>::value == false;
 *           vec<cl_short, N> if T is a signed 16-bit integer;
 *           vec<cl_ushort, N> if T is an unsigned 16-bit integer;
 *           vec<cl_int, N> if T is a signed 32-bit integer;
 *           vec<cl_uint, N> if T is an unsigned 32-bit integer;
 *           vec<cl_long, N> if T is a signed 64-bit integer
 *           vec<cl_ulong, N> if T is an unsigned 64-bit integer
 * @param t The object to be converted.
 * @return An object of type U with an equivalent value to t.
 */
#if defined __SYCL_DEVICE_ONLY__
template <typename T, int N,
          typename U = cl::sycl::vec<deduce_integral_t<T>, N>>
auto cpp_to_cl_cast(const cl::sycl::vec<T, N>& v) noexcept
    -> requires_is_same_t<
        decltype(std::declval<U>().get_data()),
        decltype(std::declval<cl::sycl::vec<deduce_integral_t<T>, N>>()
                     .get_data())> {
  return v.template as<U>().get_data();
}
#else
template <typename T, int N,
          typename U = cl::sycl::vec<deduce_integral_t<T>, N>>
auto cpp_to_cl_cast(const cl::sycl::vec<T, N>& v) noexcept
    -> requires_is_same_t<U, cl::sycl::vec<deduce_integral_t<T>, N>> {
  return v.template as<U>();
}
#endif  // defined __SYCL_DEVICE_ONLY__

/**
 * @brief Deduces the correct OpenCL floating-point type from a C++ type
 *        conforming to IEEE 754/IEC 559 floating-point numbers.
 *
 *        cl_float if T conforms to the IEEE 754/IEC 559 single-precision
 * floating-point specification;
 *        cl_double if T conforms to the IEEE 754/IEC 559 double-precision
 * floating-point specification.
 * @tparam T A C++ type conforming to IEEE 754/IEC 559 half-precision,
 *           single-precision, or double-precision floating-point numbers.
 */
template <typename T>
using deduce_iec559_t = enable_if_t<
    (std::numeric_limits<T>::is_iec559 && (sizeof(T) == 4 || sizeof(T) == 8)),
    conditional_t<sizeof(T) == 4, cl::sycl::cl_float, cl::sycl::cl_double>>;

/**
 * @brief  Converts a C++ type to the equivalent OpenCL type.
 * @tparam T A C++ floating-point type conforming to IEEE 754/IEC 559
 * half-precision, single-precision, or double-precision floating-point numbers.
 * @tparam U cl_float if T conforms to the IEEE 754/IEC 559 single-precision
 * floating-point specification;
 *           cl_double if T conforms to the IEEE 754/IEC 559 double-precision
 * floating-point specification.
 * @param t The object to be converted.
 * @return An object of type U with an equivalent value to t.
 */
template <typename T, typename U = deduce_iec559_t<T>>
constexpr auto cpp_to_cl_cast(const T t) noexcept
    -> requires_is_same_t<U, deduce_iec559_t<T>> {
  return static_cast<U>(t);
}

/**
 * @brief  Converts a cl::sycl::vec<T, N> type to the equivalent OpenCL type.
 * @tparam T A C++ floating-point type conforming to IEEE 754/IEC 559
 * single-precision or double-precision floating-point numbers.
 * @tparam N The dimension of the vector.
 * @tparam U vec<cl_float, N> if T conforms to the IEEE 754/IEC 559
 * single-precision floating-point specification;
 *           vec<cl_double, N> if T conforms to the IEEE 754/IEC 559
 * double-precision floating-point specification.
 * @param v The object to be converted.
 * @return An object of type U, with a value equivalent to v.
 */
#if defined __SYCL_DEVICE_ONLY__
template <typename T, int N, typename U = cl::sycl::vec<deduce_iec559_t<T>, N>>
auto cpp_to_cl_cast(const cl::sycl::vec<T, N>& v) noexcept
    -> requires_is_same_t<
        decltype(std::declval<U>().get_data()),
        decltype(
            std::declval<cl::sycl::vec<deduce_iec559_t<T>, N>>().get_data())> {
  return v.template as<U>().get_data();
}
#else
template <typename T, int N, typename U = cl::sycl::vec<deduce_iec559_t<T>, N>>
auto cpp_to_cl_cast(const cl::sycl::vec<T, N>& v) noexcept
    -> requires_is_same_t<U, cl::sycl::vec<deduce_iec559_t<T>, N>> {
  return v.template as<U>();
}
#endif  // defined __SYCL_DEVICE_ONLY__

/**
 * @brief  Converts a C++ type to the equivalent OpenCL type.
 *
 * Specific overload for cl::sycl::half. This is an identity function, as there
 * is no other C++ half type in C++11.
 *
 * @param h The object to be converted
 * @return `h`
 */
inline cl::sycl::half cpp_to_cl_cast(const cl::sycl::half h) noexcept {
  return h;
}

/**
 * @brief Converts cl::sycl::vec<T, N> to the equivalent OpenCL type.
 *
 * Specific overload for cl::sycl::vec<cl::sycl::half, N>. This is an identity
 * function, as there is no other C++ half type in C++11.
 *
 * @tparam N The dimension of the vector.
 * @param v The object to be converted.
 * @return `v`
 */
#if defined __SYCL_DEVICE_ONLY__
template <int N>
constexpr auto cpp_to_cl_cast(
    const ::cl::sycl::vec<::cl::sycl::half, N>& v) noexcept
    -> decltype(v.get_data()) {
  return v.get_data();
}
#else
template <int N>
constexpr cl::sycl::vec<cl::sycl::half, N> cpp_to_cl_cast(
    const cl::sycl::vec<cl::sycl::half, N>& v) noexcept {
  return v;
}
#endif  // defined __SYCL_DEVICE_ONLY__

/**
 * @brief  Converts a multi_ptr to a raw pointer, preserving the address space.
 * @tparam P Pointer type.
 * @tparam AddressSpace Pointer address space.
 * @param t The object to be converted.
 * @return The underlying pointer of p.
 */
#if defined __SYCL_DEVICE_ONLY__
template <typename T, int N, access::address_space AddressSpace>
auto cpp_to_cl_cast(
    ::cl::sycl::multi_ptr<::cl::sycl::vec<T, N>, AddressSpace> p) noexcept
    -> decltype(p->get_data_ptr()) {
  return p->get_data_ptr();
}
#endif  // defined __SYCL_DEVICE_ONLY__

template <typename P, access::address_space AddressSpace>
auto cpp_to_cl_cast(::cl::sycl::multi_ptr<P, AddressSpace> p) noexcept
    -> decltype(p.get()) {
  return p.get();
}

/**
 * @brief Converts swizzled_vec<T, N> to the equivalent OpenCL type
 *
 * @tparam T The underlying type of the swizzled_vec
 * @tparam kElems The number of elements of the swizzled_vec
 * @tparam Indexes The indexes used to access the original vec
 *         of the swizzled_vec
 * @param v The object to be converted
 * @return swizzled_vec cast to an OpenCL type
 */
template <typename T, int kElems, int... Indexes>
auto cpp_to_cl_cast(
    const cl::sycl::swizzled_vec<T, kElems, Indexes...>& v) noexcept
    -> decltype(cpp_to_cl_cast(
        static_cast<detail::common_return_t<vec<T, sizeof...(Indexes)>,
                                            decltype(v)>>(v))) {
  return cpp_to_cl_cast(
      static_cast<
          detail::common_return_t<vec<T, sizeof...(Indexes)>, decltype(v)>>(v));
}

}  // namespace detail
}  // namespace sycl
}  // namespace cl
#endif  // RUNTIME_INCLUDE_SYCL_CPP_TO_CL_CAST_H_
