/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file storage_mem.h

  \brief This file implements an internal base class for memory objects.
*/

#ifndef RUNTIME_INCLUDE_SYCL_STORAGE_MEM_H_
#define RUNTIME_INCLUDE_SYCL_STORAGE_MEM_H_

#include "SYCL/allocator.h"
#include "SYCL/common.h"
#include "SYCL/index_array.h"

namespace cl {
namespace sycl {

enum class write_back : bool {
  disable_write_back = false,
  enable_write_back = true
};

class property_list;

/** @cond COMPUTECPP_DEV */
/** @brief A common base class for memory objects
*/
class COMPUTECPP_EXPORT storage_mem {
 public:
  storage_mem();

  explicit storage_mem(dmem_shptr impl);

  virtual ~storage_mem();

  COMPUTECPP_TEST_VIRTUAL size_t get_size() const;

  COMPUTECPP_TEST_VIRTUAL size_t get_count() const;

  COMPUTECPP_TEST_VIRTUAL detail::index_array get_range_impl() const;

  COMPUTECPP_TEST_VIRTUAL dmem_shptr get_impl() const;

  COMPUTECPP_TEST_VIRTUAL void set_as_kernel_arg(
      const cl::sycl::kernel& syclKernel, unsigned int index);

  COMPUTECPP_TEST_VIRTUAL void set_final_data(std::weak_ptr<void> finalData);

  COMPUTECPP_TEST_VIRTUAL void set_final_data(void* finalData);

  COMPUTECPP_TEST_VIRTUAL void set_write_back(bool flag = true);

  /*!
  @brief Copy constructor. Copies the reference of the implementation of the rhs
  object
  @param rhs the object whose implementation will be copied
  */
  storage_mem(const storage_mem& rhs);

  /*!
  @brief Move constructor. Moves the reference of the implementation of the rhs
  object
  @param rhs the object whose implementation will be moved
  */
  storage_mem(storage_mem&& rhs);

  /*!
  @brief Copy Assignment Operator. Copies the reference of the implementation of
  the rhs object
  @param rhs the object whose implementation will be copied
  */
  storage_mem& operator=(const storage_mem& rhs);

  /*!
  @brief Move Assignment Operator. Moves the reference of the implementation of
  the rhs object
  @param rhs the object whose implementation will be moved
  */
  storage_mem& operator=(storage_mem&& rhs);

  /**
   * @brief Determines if lhs and rhs are equal
   * @param lhs Left-hand-side object in comparison
   * @param rhs Right-hand-side object in comparison
   * @return True if same underlying object
   */
  friend inline bool operator==(const storage_mem& lhs,
                                const storage_mem& rhs) {
    return (lhs.get_impl() == rhs.get_impl());
  }

  /**
   * @brief Determines if lhs and rhs are not equal
   * @param lhs Left-hand-side object in comparison
   * @param rhs Right-hand-side object in comparison
   * @return True if different underlying objects
   */
  friend inline bool operator!=(const storage_mem& lhs,
                                const storage_mem& rhs) {
    return !(lhs == rhs);
  }

 protected:
  /*!
   * @brief Sets the implementation pointer
   */
  void set_impl(dmem_shptr impl);

  /*!
   * @brief Retrieves the allocator that was used on construction
   * @return Pointer to the type-erased allocator object
   **/
  detail::base_allocator* get_base_allocator() const;

  /*!
   * @brief Retrieves the properties associated with this object
   * @return List of properties
   */
  const property_list& get_properties() const;

 private:
  dmem_shptr m_impl;
};
/** COMPUTECPP_DEV @endcond */

}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_STORAGE_MEM_H_
