/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

    * serial_memop.h *

*******************************************************************************/

/*!
  @file
  @brief This file contains internal serial memcpy and memset implementations
  used to work around some driver issues.
 */

#ifndef RUNTIME_INCLUDE_SYCL_SERIAL_MEMOP_H_
#define RUNTIME_INCLUDE_SYCL_SERIAL_MEMOP_H_

#include "SYCL/common.h"

namespace cl {
namespace sycl {

#ifdef __SYCL_DEVICE_ONLY__

/** memcpy.
 * @brief Generic memcpy implementation to work around
 * non-conformant SPIR implementations.
 * This function follows the LLVM intrinsic requirements.
 * @param dst Destination buffer.
 * @param src Source buffer.
 * @param len Buffer length.
 */
template <typename DstBufferT, typename SrcBufferT, typename SizeT>
__attribute__((__offload__)) void memcpy(DstBufferT* dst, const SrcBufferT* src,
                                         SizeT len) {
  for (SizeT i = 0; i < len; i++) {
    dst[i] = src[i];
  }
}

#define COMPUTECPP_CREATE_MEMCPY_INSTANCES(DSTBUFT, SRCBUFT)                \
  template __attribute__((__offload__)) void                                \
  memcpy<DSTBUFT, SRCBUFT, unsigned int>(DSTBUFT * dst, const SRCBUFT* src, \
                                         unsigned int len);                 \
  template __attribute__((__offload__)) void                                \
  memcpy<DSTBUFT, SRCBUFT, unsigned long long>(                             \
      DSTBUFT * dst, const SRCBUFT* src, unsigned long long len);

#define COMPUTECPP_CREATE_MEMCPY_SRC_INSTANCES(DSTBUFT)                      \
  COMPUTECPP_CREATE_MEMCPY_INSTANCES(DSTBUFT, char);                         \
  COMPUTECPP_CREATE_MEMCPY_INSTANCES(DSTBUFT,                                \
                                     __attribute__((address_space(1))) char) \
  COMPUTECPP_CREATE_MEMCPY_INSTANCES(DSTBUFT,                                \
                                     __attribute__((address_space(2))) char) \
  COMPUTECPP_CREATE_MEMCPY_INSTANCES(DSTBUFT,                                \
                                     __attribute__((address_space(3))) char)

COMPUTECPP_CREATE_MEMCPY_SRC_INSTANCES(char)
COMPUTECPP_CREATE_MEMCPY_SRC_INSTANCES(__attribute__((address_space(1))) char)
COMPUTECPP_CREATE_MEMCPY_SRC_INSTANCES(__attribute__((address_space(3))) char)

#undef COMPUTECPP_CREATE_MEMCPY_INSTANCES
#undef COMPUTECPP_CREATE_MEMCPY_SRC_INSTANCES

/** memset.
 * @brief Generic memset implementation to work around
 * non-conformant SPIR implementations.
 * This function follows the LLVM intrinsic requirements.
 * @param dst destination buffer.
 * @param val Set the buffer with this value.
 * @param len Buffer length.
 */
template <typename BufferT, typename SizeT>
__attribute__((__offload__)) void memset(BufferT* dst, char val, SizeT len) {
  for (SizeT i = 0; i < len; i++) {
    dst[i] = val;
  }
}

#define COMPUTECPP_CREATE_MEMSET_INSTANCES(DSTBUFT)                         \
  template __attribute__((__offload__)) void memset<DSTBUFT, unsigned int>( \
      DSTBUFT * dst, char val, unsigned int len);                           \
  template __attribute__((__offload__)) void                                \
  memset<DSTBUFT, unsigned long long>(DSTBUFT * dst, char val,              \
                                      unsigned long long len);

COMPUTECPP_CREATE_MEMSET_INSTANCES(char)
COMPUTECPP_CREATE_MEMSET_INSTANCES(__attribute__((address_space(1))) char)
COMPUTECPP_CREATE_MEMSET_INSTANCES(__attribute__((address_space(3))) char)

#undef COMPUTECPP_CREATE_MEMSET_INSTANCES

#endif  // __SYCL_DEVICE_ONLY__

}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_SERIAL_MEMOP_H_
