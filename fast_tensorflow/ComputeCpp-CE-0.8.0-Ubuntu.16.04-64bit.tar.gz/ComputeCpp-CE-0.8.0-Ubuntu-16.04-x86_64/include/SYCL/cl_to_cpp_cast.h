/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/
#ifndef RUNTIME_INCLUDE_SYCL_CL_TO_CPP_CAST_H_
#define RUNTIME_INCLUDE_SYCL_CL_TO_CPP_CAST_H_
#include "SYCL/half_type.h"
#include "SYCL/type_traits.h"
#include "SYCL/vec.h"
#include "computecpp/gsl/gsl"

namespace cl {
namespace sycl {
namespace detail {

/**
 * @brief Converts an OpenCL type to a C++ type.
 * @tparam To The type to be converted to.
 * @tparam From The type to be converted from.
 * @param from The object to be converted.
 * @returns An object equivalent to `from` with type `To`.
 */
template <typename To, typename From>
To cl_to_cpp_cast(const From& from) {
  return static_cast<To>(from);
}

#ifdef __SYCL_DEVICE_ONLY__
/**
 * @brief Converts an OpenCL type to a C++ type.
 * @tparam To The type to be converted to.
 * @tparam From The type to be converted from.
 * @param from The object to be converted.
 * @returns An object equivalent to `from` with type `To`.
 */
template <typename To, typename From, int N>
To cl_to_cpp_cast(const __sycl_vector<From, N>& from) noexcept {
  return To{computecpp::gsl::pun_cast<To&>(from)};
}
#else
/**
 * @brief Converts an OpenCL type to a C++ type.
 * @tparam To The type to be converted to.
 * @tparam From The type to be converted from.
 * @param from The object to be converted.
 * @returns An object equivalent to `from` with type `To`.
 */
template <typename To, typename From, int N>
To cl_to_cpp_cast(const ::cl::sycl::vec<From, N>& from) noexcept {
  return from.template as<To>();
}
#endif  // __SYCL_DEVICE_ONLY__
}  // namespace detail
}  // namespace sycl
}  // namespace cl
#endif  // RUNTIME_INCLUDE_SYCL_CL_TO_CPP_CAST_H_
