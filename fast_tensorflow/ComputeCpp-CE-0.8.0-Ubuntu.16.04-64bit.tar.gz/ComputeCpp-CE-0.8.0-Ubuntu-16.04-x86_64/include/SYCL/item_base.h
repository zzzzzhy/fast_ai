/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file item_base.h

  @brief This file implements the internal base classes for \ref cl::sycl::item
  and \ref cl::sycl::nd_item.
*/

#ifndef RUNTIME_INCLUDE_SYCL_ITEM_BASE_H_
#define RUNTIME_INCLUDE_SYCL_ITEM_BASE_H_

#include "SYCL/common.h"
#include "SYCL/index_array.h"
#include "SYCL/sycl_device_builtins.h"
#include "SYCL/vec_types_defines.h"

namespace cl {
namespace sycl {
namespace detail {

class nd_item_base;

/**
* \brief It is the non-templated base class of item which contains all the
* operators
* and methods of an item struct.
*/
class item_base {
 public:
  /**
  * @internal
  * Default constructor.
  */
  item_base() : m_id(0, 0, 0), m_range(1, 1, 1), m_linearID(0){};

  /**
  * @internal
  * Default copy constructor.
  */
  item_base(const item_base &rhs) = default;

  /**
  * @internal
  * Assigns the id and range provided, then calculates the linear ids and
  * ranges.
  * @param id the detail::index_array object specifying the id.
  * @param range the detail::index_array object specifying the range in which
  * the item_base is being instantiated.
  */
  item_base(detail::index_array id, detail::index_array range);

  /**
  * @internal
  * Assigns the id, range and offset provided, then calculates the linear ids
  * and ranges.
  * @param id the detail::index_array object specifying the id.
  * @param range the detail::index_array object specifying the range in which
  * the item_base is being instantiated.
  * @param offset the detail::index_array object specifying the instantiated
  * offset.
  */
  item_base(detail::index_array id, detail::index_array range,
            detail::index_array offset);

  /**
  * \brief Returns the id for a specific dimension.
  * @param dimension of the id
  * @return the id for the specified dimension.
  * @deprecated Use get_id instead
  */
  COMPUTECPP_DEPRECATED_API("get(int) was deprecated in SYCL 1.2.1")
  size_t get(int dimension) const { return this->get_id(dimension); }

  /**
  * \brief Returns the id for a specific dimension.
  * @param dimension of the id
  * @return the id for the specified dimension.
  */
  size_t get_id(int dimension) const { return this->m_id[dimension]; }

  /**
  * \brief Returns the id for a specific dimension.
  * @param dimension of the id
  * @return the id for the specified dimension.
  */
  size_t operator[](int dimension) const { return this->get_id(dimension); }

  /**
  * \brief Calculates the linear local id.
  * @return linear local id
  */
  size_t get_linear_id() const { return this->m_linearID; }

  /**
  * @internal
  * \brief Get the range of the associated with this item.
  * @return the values of the range for all dimensions.
  */
  detail::index_array get_range() const { return this->m_range; }

  /**
   * @internal
   * Return the current offset
   */
  detail::index_array get_offset() const { return this->m_offset; }

  /// @cond COMPUTECPP_DEV

  /**
   * @brief Helper function for calling operator==() in the parent
   * @tparam dimensions Number of dimensions of the parent object
   * @param rhs Object to compare to
   * @return True if all member variables are equal to rhs member variables
   */
  template <int dimensions>
  inline bool is_equal(const item_base &rhs) const {
    return m_id.is_equal<dimensions>(rhs.m_id) &&
           m_range.is_equal<dimensions>(rhs.m_range) &&
           m_offset.is_equal<dimensions>(rhs.m_offset) &&
           (m_linearID == rhs.m_linearID);
  }

  /// COMPUTECPP_DEV @endcond

 protected:
  detail::index_array m_id;
  detail::index_array m_range;
  detail::index_array m_offset;
  size_t m_linearID;
};

/**
* \brief It is the non-templated base class of nd_item which contains all the
* operators and methods of an nd_item struct.
* In comparison to item class, nd_item class contains all the low-level OpenCL
* functionality provided by SYCL.
* This class offers the ability to the user to use mem_fence synchronization
* using the barrier method.
*/

class nd_item_base {
 public:
  /**
  * @internal
  * Default constructor.
  * Assigns default values for all fields.
  */
  nd_item_base() {}

  /**
  * @internal
  * Default constructor.
  * Assigns default values for all fields.
  */
  nd_item_base(const nd_item_base &rhs) = default;

  /**
  * @internal
  * Constructor.
  * Assigns the local size, global size, local id and global id provided, then
  * calculates the linear local and global ids and ranges.
  * @param localID the detail::index_array object specifying the local id.
  * @param globalID the detail::index_array object specifying the global id.
  * @param m_localRange the detail::index_array object specifying the local
  * size.
  * @param globalRange the detail::index_arraye object specifying the global
  * size.
  */
  nd_item_base(detail::index_array localID, detail::index_array globalID,
               detail::index_array localRange, detail::index_array globalRange,
               detail::index_array globalOffset, detail::index_array groupID)
      : m_globalItem(globalID, globalRange, globalOffset),
        m_localItem(localID, localRange),
        m_groupId(groupID) {}

  /**
  * Barrier operation.
  * @param access::fence_space enum class object that specifies the
  * memory fence associated with the barrier.
  */
  void barrier(
      access::fence_space flag = access::fence_space::global_and_local) const;

  /**
  * \brief Returns the global id for a specific dimension.
  * @param dimension of the nd_range provided
  * @return the global id for the specified dimension.
  */
  size_t get_global(unsigned int dimension) const {
    return this->m_globalItem.get_id(dimension);
  }

  /**
  * \brief Returns the local id for a specific dimension.
  * @param dimension of the nd_range provided
  * @return the local id for the specified dimension.
  */
  size_t get_local(unsigned int dimension) const {
    return this->m_localItem.get_id(dimension);
  }

  /**
  * \brief Get the global range in a specified dimension of the range
  * @param dimension the dimension of the global range to be returned.
  * @return the value of the global range in the specified dimension.
  */
  size_t get_global_range(unsigned int dimension) const {
    return this->m_globalItem.get_range()[dimension];
  }

  /**
  * Returns the local range in a specified dimension.
  * @param dimension the dimension of the local range to be returned.
  * @return the value of the local range in the specified dimension.
  */
  size_t get_local_range(unsigned int dimension) const {
    return this->m_localItem.get_range()[dimension];
  }

  /**
   * Returns the linearized global id
   */
  size_t get_global_linear_id() const {
    return this->m_globalItem.get_linear_id();
  }

  /**
   * Returns the linearized global id
   */
  size_t get_local_linear_id() const {
    return this->m_localItem.get_linear_id();
  }

  /**
  * Returns the current group id in a given dimension.
  * @param dimension the dimension of the id to be returned.
  * @return the value of the group range in the specified dimension.
  */
  size_t get_group(unsigned int dim) const { return m_groupId[dim]; }

  /// @cond COMPUTECPP_DEV

  /**
   * @brief Helper function for calling operator==() in the parent
   * @tparam dimensions Number of dimensions of the parent object
   * @param rhs Object to compare to
   * @return True if all member variables are equal to rhs member variables
   */
  template <int dimensions>
  inline bool is_equal(const nd_item_base &rhs) const {
    return m_globalItem.is_equal<dimensions>(rhs.m_globalItem) &&
           m_localItem.is_equal<dimensions>(rhs.m_localItem) &&
           m_groupId.is_equal<dimensions>(rhs.m_groupId);
  }

  /// COMPUTECPP_DEV @endcond

 protected:
  /**
   * @brief Retrieves the global item
   * @return Global item associated with this nd_item
   */
  detail::item_base get_global_item() const noexcept { return m_globalItem; }

  /**
   * @brief Retrieves the local item
   * @return Local item associated with this nd_item
   */
  detail::item_base get_local_item() const noexcept { return m_localItem; }

  /**
   * @brief Retrieves the group ID
   * @return ID of the group associated with this nd_item
   */
  detail::index_array get_group_id() const noexcept { return m_groupId; }

 private:
  // Expose members to item_base, don't create a public interface
  friend class detail::item_base;

  detail::item_base m_globalItem;
  detail::item_base m_localItem;
  detail::index_array m_groupId;
};

/**
 * @brief Base class of the h_item class.
 *
 *        Stores the global item, the logical local item,
 *        and the physical local range.
 *        h_item has basically the same data layout as nd_item,
 *        that's why this class inherits from nd_item_base,
 *        but it performs protected inheritance because there are some nd_item
 *        member functions that should not be public in h_item.
 */
class h_item_base : protected nd_item_base {
 public:
  /**
   * @brief Initializes all IDs to zeros and ranges to ones
   */
  h_item_base() = default;

  /**
   * @brief Constructor from a logical item, global item,
   *        and physical local range
   * @param logicalLocalID Work-item logical local ID
   * @param globalID Work-item global ID
   * @param logicalLocalRange Range of parallel_for_work_item
   * @param globalRange Global range of the kernel invocation
   * @param physicalLocalRange Local range of parallel_for_work_group
   */
  h_item_base(detail::index_array logicalLocalID, detail::index_array globalID,
              detail::index_array logicalLocalRange,
              detail::index_array globalRange,
              detail::index_array physicalLocalRange)
      : nd_item_base(logicalLocalID, globalID, logicalLocalRange, globalRange,
                     index_array{0, 0, 0}, physicalLocalRange) {}

  /**
   * @brief Retrieves the physical local range it was constructed with.
   *
   *        Treats the group ID stored in nd_item_base as a range.
   * @return Physical local range
   */
  detail::index_array get_physical_local_range() const noexcept {
    return this->get_group_id();
  }
};

/*********************
* class item_base *
*********************/

inline item_base::item_base(detail::index_array id, detail::index_array range,
                            detail::index_array offset)
    : m_id(id), m_range(range), m_offset(offset) {
  m_linearID = detail::construct_linear_row_major_index(
      m_id[0], m_id[1], m_id[2], m_range[0], m_range[1], m_range[2]);
}

inline item_base::item_base(detail::index_array id, detail::index_array range)
    : item_base(id, range, detail::index_array(0, 0, 0)) {}

/*********************
* class nd_item_base *
*********************/

inline void nd_item_base::barrier(access::fence_space flag) const {
#ifdef __SYCL_DEVICE_ONLY__
  ::cl::sycl::detail::barrier(static_cast<cl_uint>(flag));
#else
  ::cl::sycl::detail::host_barrier(*this);
#endif
}

}  // namespace detail
}  // namespace sycl
}  // namespace cl

#endif  // RUNTIME_INCLUDE_SYCL_ITEM_BASE_H_
