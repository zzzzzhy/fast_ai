/*****************************************************************************

    Copyright (C) 2002-2018 Codeplay Software Limited
    All Rights Reserved.

    Codeplay's ComputeCpp

*******************************************************************************/

/*!
  @file sycl_math_common_builtins.h

  @brief Defines the public interface for the SYCL common math built-in
  functions. See
  Table 4.108 of SYCL Specification Version 1.2.1 for more details.
*/
#ifndef RUNTIME_INCLUDE_SYCL_SYCL_MATH_BUILTINS_INTEGRAL_H_
#define RUNTIME_INCLUDE_SYCL_SYCL_MATH_BUILTINS_INTEGRAL_H_

#include "SYCL/cpp_to_cl_cast.h"
#include "SYCL/gen_type_traits.h"
#include "SYCL/meta.h"
#include "SYCL/sycl_math_builtin_symbols.h"
#include "SYCL/type_traits.h"
#include "computecpp/gsl/gsl"

#ifndef __SYCL_DEVICE_ONLY__
#define COMPUTECPP_DETAIL_NAMESPACE abacus
#endif  // __SYCL_DEVICE_ONLY__

#if defined(__SYCL_DEVICE_ONLY__)
#define COMPUTECPP_BUILTIN_INTEGER_INVOKE2(...) \
  COMPUTECPP_BUILTIN_INVOKE2(__VA_ARGS__)
#else
#define COMPUTECPP_BUILTIN_INTEGER_INVOKE2(f, ...) \
  COMPUTECPP_BUILTIN_INVOKE2(detail::integer::f, __VA_ARGS__)
#endif  // __SYCL_DEVICE_ONLY_

namespace cl {
namespace sycl {
namespace detail {
template <typename I, COMPUTECPP_REQUIRES((std::is_integral<I>::value))>
make_unsigned_t<I> make_genuint_impl(I);

template <typename I, int N, COMPUTECPP_REQUIRES((std::is_integral<I>::value))>
vec<make_unsigned_t<I>, N> make_genuint_impl(vec<I, N>);

template <typename T>
using make_genuint_t = decltype(make_genuint_impl(std::declval<T>()));
}  // namespace detail

/**
 * @brief Returns `|x|`
 * @tparam I must model geninteger.
 * @param x
 * @return `x` if `0 <= x`, `-x` otherwise.
 */
template <typename I,
          COMPUTECPP_REQUIRES((detail::builtin::is_geninteger<I>::value))>
auto abs(I x) noexcept -> detail::make_genuint_t<I> {
  return COMPUTECPP_BUILTIN_INVOKE1(abs, detail::make_genuint_t<I>, x);
}

/**
 * @brief Returns `|x - y|` without modulo overflow.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES((detail::builtin::is_geninteger<I>::value))>
auto abs_diff(I x, I y) noexcept -> detail::make_genuint_t<I> {
// TODO(Gordon): Temporary fix to get past error with macros, to be resolved
// before merging!
#if defined(__SYCL_DEVICE_ONLY__)
  return COMPUTECPP_BUILTIN_INVOKE2(abs_diff, detail::make_genuint_t<I>, x, y);
#else
  return COMPUTECPP_BUILTIN_INVOKE2(detail::integer::abs_diff,
                                    detail::make_genuint_t<I>, x, y);
#endif  // __SYCL_DEVICE_ONLY_
}

/**
 * @brief Returns `x + y` and saturates the result.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I add_sat(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(add_sat, I, x, y);
}

/**
 * @brief Returns `(x + y) >> 1`. The intermediate sum does not modulo overflow.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I hadd(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(hadd, I, x, y);
}

/**
* @brief Returns `(x + y + 1) >> 1`. The intermediate sum does not modulo
* overflow.
* @tparam I must model geninteger.
*/
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I rhadd(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(rhadd, I, x, y);
}

/**
 * @brief Returns `min(max(x, minval), maxval)`. Results are undefined if
 * `minval > maxval`.
 * @tparam I must model geninteger.
 * @pre minval <= maxval.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I clamp(I x, I minval, I maxval) noexcept {
  // TODO(@cjdb, CPP-673) Uncomment
  // Expects(minval <= maxval);
  return COMPUTECPP_BUILTIN_INVOKE3(clamp, I, x, minval, maxval);
}

/**
 * @brief Returns `min(max(x, minval), maxval)`. Results are undefined if
 * `minval > maxval`.
 * @tparam I must model geninteger
 * @tparam S must model sgeninteger.
 * @pre minval <= maxval.
 */
template <typename I, typename S,
          COMPUTECPP_REQUIRES((detail::builtin::is_geninteger<I>::value &&
                               detail::builtin::is_sgeninteger<S>::value))>
I clamp(I x, S minval, S maxval) noexcept {
  // TODO(@cjdb, CPP-673) Uncomment
  // Expects(minval <= maxval);
  return COMPUTECPP_BUILTIN_INVOKE3(clamp, I, x, minval, maxval);
}

/**
 * @brief Returns the number of leading 0-bits in `x`, starting at the most
 * significant bit position.
 * @tparam I must model geninteger.
 */
template <typename I, typename return_t = detail::collapse_swizzled_vec_t<I>,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
return_t clz(I x) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE1(clz, return_t, x);
}

/**
 * @brief Returns `mul_hi(a, b) + c`.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I mad_hi(I a, I b, I c) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE3(mad_hi, I, a, b, c);
}

/**
 * @brief Returns `a * b + c` and saturates the result.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I mad_sat(I a, I b, I c) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE3(mad_sat, I, a, b, c);
}

/**
 * @brief Returns y if `x < y`, otherwise it returns x.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I max(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(max, I, x, y);
}

/**
 * @brief Returns y if `x < y`, otherwise it returns x.
 * @tparam I must model geninteger.
 * @tparam S must model sgeninteger.
 */
template <typename I, typename S,
          COMPUTECPP_REQUIRES((detail::builtin::is_geninteger<I>::value &&
                               detail::builtin::is_sgeninteger<S>::value))>
I max(I x, S y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(max, I, x, y);
}

/**
 * @brief Returns y if `y < x`, otherwise it returns x.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I min(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(min, I, x, y);
}

/**
 * @brief Returns y if `y < x`, otherwise it returns x.
 * @tparam I must model geninteger.
 * @tparam S must model sgeninteger.
 */
template <typename I, typename S,
          COMPUTECPP_REQUIRES((detail::builtin::is_geninteger<I>::value &&
                               detail::builtin::is_sgeninteger<S>::value))>
I min(I x, S y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(min, I, x, y);
}

/**
 * @brief Computes `x * y` and returns the high half of the product of `x` and
 * `y`.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I mul_hi(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(mul_hi, I, x, y);
}

/**
 * @brief For each element in v, the bits are shifted left by the number of bits
 * given by the corresponding element in i (subject to usual shift modulo rules
 * described in section 6.3).
 *
 * Bits shifted off the left side of the element are shifted back in from the
 * right.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I rotate(I v, I i) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(rotate, I, v, i);
}

/**
 * @brief Returns `x - y` and saturates the result.
 * @tparam I must model geninteger.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
I sub_sat(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(sub_sat, I, x, y);
}

/**
 * @brief Returns `result[i] = (hi[i] << 8) | lo[i]`
 * @tparam I1 must model geninteger. The integral size of I1 must be double the
 * integral size of I2.
 * @tparam I2 must model geninteger.
 */
template <typename I1, typename I2,
          COMPUTECPP_REQUIRES(
              computecpp::gsl::or_<
                  detail::builtin::is_geninteger8bit<I1>::value &&
                      detail::builtin::is_ugeninteger8bit<I2>::value,
                  detail::builtin::is_geninteger16bit<I1>::value &&
                      detail::builtin::is_ugeninteger16bit<I2>::value,
                  detail::builtin::is_geninteger32bit<I1>::value &&
                      detail::builtin::is_ugeninteger32bit<I2>::value>::value)>
auto upsample(I1 hi, I2 lo) noexcept
    -> decltype(::cl::sycl::detail::double_width_cast(std::declval<I1>())) {
  return COMPUTECPP_BUILTIN_INVOKE2(
      upsample,
      decltype(::cl::sycl::detail::double_width_cast(std::declval<I1>())), hi,
      lo);
}

/**
 * @brief Returns the number of non-zero bits in `x`.
 * @tparam I must model geninteger.
 */
template <typename I, typename return_t = detail::collapse_swizzled_vec_t<I>,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger<I>::value)>
return_t popcount(I x) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE1(popcount, return_t, x);
}

/**
 * @brief Multipy two 24-bit integer values `x` and `y` and add the 32-bit
 * integer result to the 32-bit integer `z`.
 *
 * Refer to definition of `mul24` to see how the 24-bit integer multiplication
 * is performed.
 * @tparam I must model geninteger32bit.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger32bit<I>::value)>
I mad24(I x, I y, I z) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE3(mad24, I, x, y, z);
}

/**
 * @brief Multiply two 24-bit integer values `x` and `y`. `x` and `y` are 32-bit
 * integers but only the low 24-bits are used to perform the multiplication.
 *
 * `mul24` should only be used when values in `x` and `y` are in the range
 * [-223, 223 - 1] if `x` and `y` are signed integers and in the range [0, 224 -
 * 1] if `x` and `y` are unsigned integers. If `x` and `y` are not in this
 * range, the multiplication result is implementation-defined.
 * @tparam I must model geninteger32bit.
 */
template <typename I,
          COMPUTECPP_REQUIRES(detail::builtin::is_geninteger32bit<I>::value)>
I mul24(I x, I y) noexcept {
  return COMPUTECPP_BUILTIN_INVOKE2(mul24, I, x, y);
}
}  // namespace sycl
}  // namespace cl

#if !defined(__SYCL_DEVICE_ONLY__)
#undef COMPUTECPP_DETAIL_NAMESPACE
#endif  // !defined(__SYCL_DEVICE_ONLY__)

#endif  // RUNTIME_INCLUDE_SYCL_SYCL_MATH_BUILTINS_INTEGRAL_H_