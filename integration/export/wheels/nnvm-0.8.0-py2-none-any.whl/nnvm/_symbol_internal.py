"""Module space to register internal functions. Leave empty"""
